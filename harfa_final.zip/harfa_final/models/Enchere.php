<?php
/**
 * =========================================================================
 *  حرفة Tunisie — Model ENCHERE
 *  Gestion des enchères avec PDO
 * =========================================================================
 * Ce fichier gère toutes les opérations CRUD (Create, Read, Update, Delete)
 * sur les enchères de la plateforme. Utilise PDO pour les requêtes paramétrées.
 */

class Enchere
{
    /**
     * @var PDO Instance de connexion à la base de données
     */
    private PDO $pdo;

    /**
     * __construct - Constructeur
     * 
     * @param PDO $pdo Instance PDO de la base de données
     */
    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    // ═══════════════════════════════════════════════════════════════
    // OPÉRATIONS DE LECTURE (SELECT)
    // ═══════════════════════════════════════════════════════════════

    /**
     * getAllEncheres - Récupère toutes les enchères avec détails et pagination
     * 
     * @param int $page   Numéro de page (par défaut 1)
     * @param int $limit  Nombre d'enchères par page (par défaut 20)
     * @return array      Array d'enchères avec détails du projet et investisseur
     */
    public function getAllEncheres(int $page = 1, int $limit = 20): array
    {
        $offset = ($page - 1) * $limit;

        $sql = "SELECT e.id, e.id_projet, e.id_investisseur, e.montant, e.message, e.statut, e.date_enchere,
                       p.titre AS projet_titre, p.budget_min AS projet_budget_min,
                       u.nom AS inv_nom, u.prenom AS inv_prenom, u.email AS inv_email
                FROM enchere e
                JOIN projet p ON p.id      = e.id_projet
                JOIN user   u ON u.id_user = e.id_investisseur
                ORDER BY e.date_enchere DESC
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * getEnchersByProjet - Récupère toutes les enchères d'un projet
     * Triées par montant décroissant
     * 
     * @param int $id_projet ID du projet
     * @return array         Array d'enchères pour ce projet
     */
    public function getEnchersByProjet(int $id_projet): array
    {
        $stmt = $this->pdo->prepare(
            "SELECT e.id, e.montant, e.message, e.statut, e.date_enchere,
                    u.id_user, u.nom AS inv_nom, u.prenom AS inv_prenom, u.email AS inv_email
             FROM enchere e
             JOIN user u ON u.id_user = e.id_investisseur
             WHERE e.id_projet = :id
             ORDER BY e.montant DESC, e.date_enchere DESC"
        );
        $stmt->execute([':id' => $id_projet]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * getEnchersByInvestisseur - Récupère toutes les enchères d'un investisseur
     *
     * @param int $id_user ID de l'investisseur
     * @return array       Array d'enchères de cet investisseur
     */
    public function getEnchersByInvestisseur(int $id_user): array
    {
        $stmt = $this->pdo->prepare(
            "SELECT e.id, e.id_projet, e.montant, e.message, e.statut, e.date_enchere,
                    p.titre AS projet_titre, p.budget_min AS projet_budget_min, p.status AS projet_status
             FROM enchere e
             JOIN projet p ON p.id = e.id_projet
             WHERE e.id_investisseur = :id
             ORDER BY e.date_enchere DESC"
        );
        $stmt->execute([':id' => $id_user]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * getEnchereById - Récupère une enchère par son ID
     *
     * @param int $id ID de l'enchère
     * @return array|null Données de l'enchère ou null si non trouvée
     */
    public function getEnchereById(int $id): ?array
    {
        $stmt = $this->pdo->prepare(
            "SELECT e.id, e.id_projet, e.id_investisseur, e.montant, e.message, e.statut, e.date_enchere,
                    p.titre AS projet_titre, p.budget_min,
                    u.nom AS inv_nom, u.prenom AS inv_prenom, u.email AS inv_email
             FROM enchere e
             JOIN projet p ON p.id      = e.id_projet
             JOIN user   u ON u.id_user = e.id_investisseur
             WHERE e.id = :id"
        );
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * getHighestBid - Retourne le montant de la meilleure enchère d'un projet
     *
     * @param int $id_projet ID du projet
     * @return float         Montant le plus élevé (0 si aucune enchère)
     */
    public function getHighestBid(int $id_projet): float
    {
        $stmt = $this->pdo->prepare(
            "SELECT COALESCE(MAX(montant), 0) FROM enchere WHERE id_projet = :id"
        );
        $stmt->execute([':id' => $id_projet]);
        return (float) $stmt->fetchColumn();
    }

    /**
     * hasAlreadyBid - Vérifie si un investisseur a déjà enchéri sur un projet
     * Empêche les enchères multiples sur un même projet
     *
     * @param int $id_projet       ID du projet
     * @param int $id_investisseur ID de l'investisseur
     * @return bool                true si l'investisseur a déjà enchéri
     */
    public function hasAlreadyBid(int $id_projet, int $id_investisseur): bool
    {
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(*) FROM enchere WHERE id_projet = :p AND id_investisseur = :u"
        );
        $stmt->execute([':p' => $id_projet, ':u' => $id_investisseur]);
        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * getProjetsOuverts - Récupère tous les projets ouverts aux enchères
     * Inclut les statistiques (meilleure offre, nombre d'enchères)
     *
     * @return array Array de projets ouverts avec stats
     */
    public function getProjetsOuverts(): array
    {
        $stmt = $this->pdo->prepare(
            "SELECT p.id, p.titre, p.budget_min, p.status, p.date_creation,
                    c.id AS categorie_id, c.nom AS categorie_nom,
                    COALESCE(MAX(e.montant),0) AS meilleure_offre,
                    COUNT(DISTINCT e.id) AS nb_encheres
             FROM projet p
             LEFT JOIN categorie c ON c.id = p.id_categorie
             LEFT JOIN enchere   e ON e.id_projet = p.id
             WHERE p.status = 'ouvert'
             GROUP BY p.id, p.titre, p.budget_min, p.status, p.date_creation, c.id, c.nom
             ORDER BY p.date_creation DESC"
        );
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * getProjetById - Récupère les détails d'un projet par son ID
     *
     * @param int $id ID du projet
     * @return array|null Données du projet ou null
     */
    public function getProjetById(int $id): ?array
    {
        $stmt = $this->pdo->prepare(
            "SELECT p.id, p.titre, p.budget_min, p.status, p.date_creation,
                    c.nom AS categorie_nom,
                    COALESCE(MAX(e.montant),0) AS meilleure_offre,
                    COUNT(DISTINCT e.id) AS nb_encheres
             FROM projet p
             LEFT JOIN categorie c ON c.id = p.id_categorie
             LEFT JOIN enchere   e ON e.id_projet = p.id
             WHERE p.id = :id
             GROUP BY p.id, p.titre, p.budget_min, p.status, p.date_creation, c.nom"
        );
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * getBudgetMin - Récupère le budget minimum d'un projet
     *
     * @param int $id_projet ID du projet
     * @return float         Budget minimum du projet
     */
    public function getBudgetMin(int $id_projet): float
    {
        $stmt = $this->pdo->prepare("SELECT budget_min FROM projet WHERE id = :id");
        $stmt->execute([':id' => $id_projet]);
        return (float) $stmt->fetchColumn();
    }

    // ═══════════════════════════════════════════════════════════════
    // STATISTIQUES
    // ═══════════════════════════════════════════════════════════════

    /**
     * countTotal - Compte le nombre total d'enchères
     *
     * @return int Nombre total d'enchères
     */
    public function countTotal(): int
    {
        return (int) $this->pdo->query("SELECT COUNT(*) FROM enchere")->fetchColumn();
    }

    /**
     * sumMontantAccepte - Calcule le montant total des enchères acceptées
     *
     * @return float Montant total accepté
     */
    public function sumMontantAccepte(): float
    {
        return (float) $this->pdo->query(
            "SELECT COALESCE(SUM(montant), 0) FROM enchere WHERE statut = 'acceptee'"
        )->fetchColumn();
    }

    /**
     * countProjetsFinances - Compte le nombre de projets ayant reçu une enchère acceptée
     *
     * @return int Nombre de projets financés
     */
    public function countProjetsFinances(): int
    {
        return (int) $this->pdo->query(
            "SELECT COUNT(DISTINCT id_projet) FROM enchere WHERE statut = 'acceptee'"
        )->fetchColumn();
    }

    /**
     * getStatistiques - Retourne un tableau complet de statistiques
     *
     * @return array Array contenant statistiques globales
     */
    public function getStatistiques(): array
    {
        $stats = [
            'total_encheres'         => $this->countTotal(),
            'montant_total_accepte'  => $this->sumMontantAccepte(),
            'projets_finances'       => $this->countProjetsFinances()
        ];

        return $stats;
    }

    // ═══════════════════════════════════════════════════════════════
    // OPÉRATIONS D'ÉCRITURE (INSERT, UPDATE, DELETE)
    // ═══════════════════════════════════════════════════════════════

    /**
     * addEnchere - Ajoute une nouvelle enchère
     * La date est automatiquement définie à NOW()
     *
     * @param int $id_projet        ID du projet
     * @param int $id_investisseur  ID de l'investisseur
     * @param float $montant        Montant de l'enchère
     * @param string $message       Message de motivation (optionnel)
     * @return bool                 true si succès, false sinon
     */
    public function addEnchere(int $id_projet, int $id_investisseur, float $montant, string $message = ''): bool
    {
        try {
            $stmt = $this->pdo->prepare(
                "INSERT INTO enchere (id_projet, id_investisseur, montant, message, statut, date_enchere)
                 VALUES (:p, :u, :m, :msg, 'en_attente', NOW())"
            );
            
            $result = $stmt->execute([
                ':p'   => $id_projet,
                ':u'   => $id_investisseur,
                ':m'   => $montant,
                ':msg' => trim($message)
            ]);

            return $result;
        } catch (PDOException $e) {
            error_log("Erreur addEnchere : " . $e->getMessage());
            return false;
        }
    }

    /**
     * updateStatut - Met à jour le statut d'une enchère
     * Statuts valides : en_attente, acceptee, refusee
     *
     * @param int $id       ID de l'enchère
     * @param string $statut Nouveau statut
     * @return bool         true si succès, false sinon
     */
    public function updateStatut(int $id, string $statut): bool
    {
        // Validation du statut
        $statuts_valides = ['en_attente', 'acceptee', 'refusee'];
        if (!in_array($statut, $statuts_valides, true)) {
            return false;
        }

        try {
            $stmt = $this->pdo->prepare("UPDATE enchere SET statut = :s WHERE id = :id");
            return $stmt->execute([':s' => $statut, ':id' => $id]);
        } catch (PDOException $e) {
            error_log("Erreur updateStatut : " . $e->getMessage());
            return false;
        }
    }

    /**
     * deleteEnchere - Supprime une enchère
     *
     * @param int $id ID de l'enchère
     * @return bool   true si supprimée, false sinon
     */
    public function deleteEnchere(int $id): bool
    {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM enchere WHERE id = :id");
            return $stmt->execute([':id' => $id]);
        } catch (PDOException $e) {
            error_log("Erreur deleteEnchere : " . $e->getMessage());
            return false;
        }
    }

    /**
     * searchEncheres - Recherche des enchères avec des filtres
     * Filtres possibles : id_projet, statut, date_debut, date_fin
     *
     * @param array $filtres Array de filtres [clé => valeur]
     * @return array         Array d'enchères correspondant aux critères
     */
    public function searchEncheres(array $filtres = []): array
    {
        $sql = "SELECT e.id, e.id_projet, e.id_investisseur, e.montant, e.message, e.statut, e.date_enchere,
                       p.titre AS projet_titre,
                       u.nom AS inv_nom, u.prenom AS inv_prenom
                FROM enchere e
                JOIN projet p ON p.id = e.id_projet
                JOIN user   u ON u.id_user = e.id_investisseur
                WHERE 1=1 ";
        
        $params = [];

        // Filtre par projet
        if (!empty($filtres['id_projet'])) {
            $sql .= " AND e.id_projet = :id_projet";
            $params[':id_projet'] = (int) $filtres['id_projet'];
        }

        // Filtre par statut
        if (!empty($filtres['statut'])) {
            $sql .= " AND e.statut = :statut";
            $params[':statut'] = $filtres['statut'];
        }

        // Filtre par date de début
        if (!empty($filtres['date_debut'])) {
            $sql .= " AND DATE(e.date_enchere) >= :date_debut";
            $params[':date_debut'] = $filtres['date_debut'];
        }

        // Filtre par date de fin
        if (!empty($filtres['date_fin'])) {
            $sql .= " AND DATE(e.date_enchere) <= :date_fin";
            $params[':date_fin'] = $filtres['date_fin'];
        }

        $sql .= " ORDER BY e.date_enchere DESC";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
