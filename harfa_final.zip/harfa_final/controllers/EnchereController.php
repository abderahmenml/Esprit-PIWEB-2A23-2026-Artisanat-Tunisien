<?php
/**
 * =========================================================================
 *  حرفة Tunisie — Controller ENCHERE
 *  Gestion des actions pour les enchères (FrontOffice + BackOffice)
 * =========================================================================
 * Ce contrôleur gère :
 * - FrontOffice : Liste projets, formulaire enchère, mes enchères
 * - BackOffice  : Dashboard, accepter/refuser enchères
 * Comprend validation PHP et gestion des messages flash
 */

require_once __DIR__ . '/../models/Enchere.php';

class EnchereController
{
    /**
     * @var Enchere Instance du model Enchere
     */
    private Enchere $model;

    /**
     * __construct - Initialise le contrôleur
     * 
     * @param PDO $pdo Instance de connexion à la base de données
     */
    public function __construct(PDO $pdo)
    {
        $this->model = new Enchere($pdo);
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    /**
     * dispatch - Aiguille les actions vers les méthodes appropriées
     * Actions disponibles : index, liste, form, add, mes_encheres, accept, refuse, delete
     * 
     * @param string $action Nom de l'action à exécuter
     */
    public function dispatch(string $action): void
    {
        match ($action) {
            // BackOffice - Gestion admin
            'index'        => $this->dashboardEncheres(),
            'accept'       => $this->accepterEnchere(),
            'refuse'       => $this->refuserEnchere(),
            'delete'       => $this->supprimerEnchere(),
            
            // FrontOffice - Investisseurs
            'liste'        => $this->listerProjets(),
            'form'         => $this->formulaireEnchere(),
            'add'          => $this->ajouterEnchere(),
            'mes_encheres' => $this->mesEncheres(),
            
            default        => $this->listerProjets(),
        };
    }

    // ═══════════════════════════════════════════════════════════════
    // BACKOFFICE - DASHBOARD ENCHÈRES
    // ═══════════════════════════════════════════════════════════════

    /**
     * dashboardEncheres - Affiche le dashboard d'administration des enchères
     * Inclus filtrage par projet, statut et date
     * Affiche aussi les statistiques globales
     * 
     * @return void Affiche la vue backoffice/investissement/index.php
     */
    private function dashboardEncheres(): void
    {
        // Vérifier que l'utilisateur est admin
        $this->requireRole('admin');

        // Récupérer toutes les enchères
        $encheres = $this->model->getAllEncheres();

        // ── FILTRAGE ────────────────────────────────────────────
        $idProjetFiltre = isset($_GET['projet']) ? (int)$_GET['projet'] : 0;
        $statutFiltre = $_GET['statut'] ?? '';
        $dateFiltre = $_GET['date'] ?? '';

        // Filtre par projet
        if ($idProjetFiltre) {
            $encheres = array_filter($encheres, fn($e) => $e['id_projet'] === $idProjetFiltre);
        }

        // Filtre par statut (en_attente, acceptee, refusee)
        if ($statutFiltre && in_array($statutFiltre, ['en_attente', 'acceptee', 'refusee'])) {
            $encheres = array_filter($encheres, fn($e) => $e['statut'] === $statutFiltre);
        }

        // Filtre par date (format YYYY-MM-DD)
        if ($dateFiltre) {
            $encheres = array_filter($encheres, fn($e) => 
                substr($e['date_enchere'], 0, 10) === $dateFiltre
            );
        }

        // ── STATISTIQUES ────────────────────────────────────────
        $stats = [
            'total'     => $this->model->countTotal(),
            'montant'   => $this->model->sumMontantAccepte(),
            'finances'  => $this->model->countProjetsFinances(),
        ];

        // Récupérer les messages flash
        $flash = $this->getFlash();

        // Charger la vue
        require_once __DIR__ . '/../views/backoffice/investissement/index.php';
    }

    /**
     * accepterEnchere - Accepte une enchère (passage au statut 'acceptee')
     * 
     * @return void Redirige vers le dashboard
     */
    private function accepterEnchere(): void
    {
        $this->requireRole('admin');
        $this->requirePost();

        $id = (int)($_POST['id'] ?? 0);

        if ($id && $this->model->updateStatut($id, 'acceptee')) {
            $this->setFlash('success', '✓ Enchère acceptée avec succès !');
        } else {
            $this->setFlash('error', '❌ Erreur : impossible d\'accepter cette enchère.');
        }

        header('Location: ?module=investissement&action=index');
        exit;
    }

    /**
     * refuserEnchere - Refuse une enchère (passage au statut 'refusee')
     * 
     * @return void Redirige vers le dashboard
     */
    private function refuserEnchere(): void
    {
        $this->requireRole('admin');
        $this->requirePost();

        $id = (int)($_POST['id'] ?? 0);

        if ($id && $this->model->updateStatut($id, 'refusee')) {
            $this->setFlash('success', '✓ Enchère refusée avec succès.');
        } else {
            $this->setFlash('error', '❌ Erreur : impossible de refuser cette enchère.');
        }

        header('Location: ?module=investissement&action=index');
        exit;
    }

    /**
     * supprimerEnchere - Supprime une enchère de la base de données
     * 
     * @return void Redirige vers le dashboard
     */
    private function supprimerEnchere(): void
    {
        $this->requireRole('admin');
        $this->requirePost();

        $id = (int)($_POST['id'] ?? 0);

        if ($id && $this->model->deleteEnchere($id)) {
            $this->setFlash('success', '✓ Enchère supprimée.');
        } else {
            $this->setFlash('error', '❌ Erreur : suppression impossible.');
        }

        header('Location: ?module=investissement&action=index');
        exit;
    }

    // ═══════════════════════════════════════════════════════════════
    // FRONTOFFICE - GESTION DES ENCHÈRES  
    // ═══════════════════════════════════════════════════════════════

    /**
     * listerProjets - Affiche la liste des projets ouverts aux enchères
     * Inclus informations : titre, budget minimum, meilleure offre, nombre d'enchères
     * 
     * @return void Affiche la vue frontoffice/investissement/liste.php
     */
    private function listerProjets(): void
    {
        // Vérifier que l'utilisateur est connecté
        $this->requireAuth();

        // Récupérer les projets ouverts avec stats
        $projets = $this->model->getProjetsOuverts();

        // Récupérer les messages flash
        $flash = $this->getFlash();

        // Charger la vue
        require_once __DIR__ . '/../views/frontoffice/investissement/liste.php';
    }

    /**
     * formulaireEnchere - Affiche le formulaire pour soumettre une enchère
     * Renforce avec validation JavaScript et PHP du côté serveur
     * 
     * @return void Affiche la vue frontoffice/investissement/form.php
     */
    private function formulaireEnchere(): void
    {
        // Vérifier que l'utilisateur est un investisseur
        $this->requireRole('investisseur');

        // Récupérer l'ID du projet depuis GET ou POST
        $idProjet = (int)($_GET['id_projet'] ?? $_POST['id_projet'] ?? 0);

        // Vérifier que l'ID du projet est valide
        if (!$idProjet) {
            $this->setFlash('error', '❌ Projet introuvable.');
            header('Location: ?module=investissement&action=liste');
            exit;
        }

        // Récupérer les détails du projet
        $projet = $this->model->getProjetById($idProjet);
        if (!$projet) {
            $this->setFlash('error', '❌ Projet introuvable.');
            header('Location: ?module=investissement&action=liste');
            exit;
        }

        // Initialiser les variables
        $errors = [];
        $old = [];
        $budget_min = $this->model->getBudgetMin($idProjet);
        $highest_bid = $this->model->getHighestBid($idProjet);
        $idUser = (int)$_SESSION['user']['id_user'];

        // ── TRAITEMENT DU FORMULAIRE ────────────────────────────
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $montant = trim($_POST['montant'] ?? '');
            $message = trim($_POST['message'] ?? '');

            // Sauvegarder les valeurs pour affichage en cas d'erreur
            $old = compact('montant', 'message');

            // ── VALIDATION PHP STRICTE ──────────────────────────

            // 1. Montant obligatoire et valide
            if ($montant === '') {
                $errors['montant'] = 'Le montant est obligatoire.';
            } elseif (!is_numeric($montant)) {
                $errors['montant'] = 'Le montant doit être un nombre valide.';
            } elseif ((float)$montant <= 0) {
                $errors['montant'] = 'Le montant doit être supérieur à 0 TND.';
            }
            // 2. Vérifier montant >= budget minimum
            elseif ((float)$montant < $budget_min) {
                $montantFormate = number_format($budget_min, 0, ',', ' ');
                $errors['montant'] = "Le montant minimum requis est {$montantFormate} TND.";
            }
            // 3. Vérifier montant > meilleure enchère existante
            elseif ($highest_bid > 0 && (float)$montant <= $highest_bid) {
                $montantFormate = number_format($highest_bid, 0, ',', ' ');
                $errors['montant'] = "Votre offre doit dépasser {$montantFormate} TND (meilleure offre actuelle).";
            }

            // 4. Message de motivation : minimum 20 caractères
            if (mb_strlen($message) < 20) {
                $longueur = mb_strlen($message);
                $errors['message'] = "Le message doit contenir au moins 20 caractères (actuellement : {$longueur}).";
            }

            // 5. Vérifier que l'investisseur n'a pas déjà enchéri
            if ($this->model->hasAlreadyBid($idProjet, $idUser)) {
                $errors['global'] = '❌ Vous avez déjà soumis une enchère pour ce projet. Un investisseur = une enchère par projet.';
            }

            // ── INSERTION SI VALIDE ─────────────────────────────
            if (empty($errors)) {
                $success = $this->model->addEnchere($idProjet, $idUser, (float)$montant, $message);

                if ($success) {
                    $this->setFlash('success', '🎉 Votre enchère a été soumise avec succès !');
                    header('Location: ?module=investissement&action=mes_encheres');
                    exit;
                } else {
                    $errors['global'] = '⚠️ Une erreur serveur est survenue. Veuillez réessayer.';
                }
            }
        }

        // Récupérer les messages flash
        $flash = $this->getFlash();

        // Charger la vue
        require_once __DIR__ . '/../views/frontoffice/investissement/form.php';
    }

    /**
     * ajouterEnchere - Alias pour formulaireEnchere (redirection POST)
     * Permet d'utiliser ?action=add ou ?action=form indifféremment
     * 
     * @return void Redirige vers formulaireEnchere()
     */
    private function ajouterEnchere(): void
    {
        $this->formulaireEnchere();
    }

    /**
     * mesEncheres - Affiche les enchères soumises par l'investisseur connecté
     * Inclus statut et détails de chaque enchère + projet
     * 
     * @return void Affiche la vue frontoffice/investissement/mes_encheres.php
     */
    private function mesEncheres(): void
    {
        // Vérifier que l'utilisateur est un investisseur
        $this->requireRole('investisseur');

        // Récupérer l'ID de l'investisseur depuis la session
        $idUser = (int)$_SESSION['user']['id_user'];

        // Récupérer ses enchères
        $encheres = $this->model->getEnchersByInvestisseur($idUser);

        // Récupérer les messages flash
        $flash = $this->getFlash();

        // Charger la vue
        require_once __DIR__ . '/../views/frontoffice/investissement/mes_encheres.php';
    }

    // ═══════════════════════════════════════════════════════════════
    // HELPERS - UTILITAIRES
    // ═══════════════════════════════════════════════════════════════

    /**
     * requireAuth - Vérifie que l'utilisateur est connecté
     * Redirige vers login si non connecté
     * 
     * @return void
     */
    private function requireAuth(): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: ?module=auth&action=login');
            exit;
        }
    }

    /**
     * requireRole - Vérifie que l'utilisateur a le rôle requis
     * Redirige vers login ou liste si accès non autorisé
     * 
     * @param string $role Rôle requis ('admin', 'investisseur', 'entrepreneur', etc.)
     * @return void
     */
    private function requireRole(string $role): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: ?module=auth&action=login');
            exit;
        }

        if ($_SESSION['user']['role'] !== $role) {
            header('Location: ?module=investissement&action=liste');
            exit;
        }
    }

    /**
     * requirePost - Vérifie que la requête est une POST
     * Utile pour les actions critiques (delete, update, insert)
     * 
     * @return void
     */
    private function requirePost(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ?module=investissement&action=index');
            exit;
        }
    }

    /**
     * setFlash - Enregistre un message flash en session
     * Messages flash : affichés une seule fois puis supprimés
     * 
     * @param string $type Type de message : 'success', 'error', 'info', 'warning'
     * @param string $msg  Contenu du message
     * @return void
     */
    private function setFlash(string $type, string $msg): void
    {
        $_SESSION['flash'] = [
            'type'    => $type,
            'message' => $msg
        ];
    }

    /**
     * getFlash - Récupère et vide le message flash
     * 
     * @return array Array vide [] ou ['type' => 'xxx', 'message' => 'yyy']
     */
    private function getFlash(): array
    {
        $flash = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $flash;
    }
}
