<?php
/**
 * =========================================================================
 *  حرفة Tunisie — FrontOffice - Liste des Projets à Financer
 * =========================================================================
 * Affiche tous les projets ouverts aux enchères avec :
 * - Titre et catégorie
 * - Budget minimum requis
 * - Meilleure offre actuelle
 * - Nombre d'enchères reçues
 * - Bouton "Enchérir"
 * 
 * Variables disponibles (passées depuis le contrôleur):
 *   $projets  : Array de projets ouverts
 *   $flash    : Messages de notification (success/error)
 */
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Investir — حرفة Tunisie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        /* ── VARIABLES DE COULEURS ────────────────────────────────────────── */
        :root { 
            --p:#8B4513;      /* Couleur primaire (marron) */
            --g:#C9933A;      /* Couleur secondaire (or) */
            --bg:#FDF6EC;     /* Couleur de fond */
        }
        
        body { 
            background:var(--bg); 
            font-family:'Segoe UI',sans-serif; 
        }

        /* ── NAVIGATION ────────────────────────────────────────────────────── */
        .navbar-harfa { 
            background:var(--p); 
            box-shadow: 0 2px 8px rgba(0,0,0,.1);
        }

        /* ── HERO SECTION ──────────────────────────────────────────────────── */
        .hero { 
            background:linear-gradient(135deg,var(--p),var(--g)); 
            color:#fff; 
            padding:3.5rem 0 2.5rem; 
        }

        /* ── CARTES DES PROJETS ────────────────────────────────────────────── */
        .card-projet { 
            border:none; 
            border-radius:14px; 
            box-shadow:0 4px 18px rgba(0,0,0,.08); 
            transition:transform .2s,box-shadow .2s; 
        }
        
        .card-projet:hover { 
            transform:translateY(-5px); 
            box-shadow:0 10px 30px rgba(0,0,0,.13); 
        }

        .top-bar { 
            height:5px; 
            background:linear-gradient(90deg,var(--p),var(--g)); 
        }

        .montant-min { 
            font-size:1.5rem; 
            font-weight:800; 
            color:var(--p); 
        }

        .badge-cat { 
            background:var(--g); 
            color:#fff; 
            font-size:.72rem; 
            border-radius:20px; 
            padding:.3em .8em; 
        }

        /* ── BARRE DE PROGRESSION ──────────────────────────────────────────── */
        .progress { 
            border-radius:4px; 
        }
        
        .progress-bar { 
            background:var(--g); 
        }

        /* ── BOUTON ENCHÉRIR ───────────────────────────────────────────────── */
        .btn-encherer { 
            background:var(--p); 
            color:#fff; 
            border-radius:8px; 
            font-weight:600; 
            transition: all .2s;
        }
        
        .btn-encherer:hover { 
            background:var(--g); 
            color:#fff; 
            transform: scale(1.02);
        }

        /* ── ÉTAT VIDE (AUCUN PROJET) ──────────────────────────────────────── */
        .empty-state { 
            text-align:center; 
            padding:4rem 0; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-harfa navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="?module=investissement&action=liste">
            حرفة <span style="color:var(--g)">Tunisie</span>
        </a>
        <div class="ms-auto d-flex align-items-center gap-3">
            <a href="?module=investissement&action=mes_encheres" class="btn btn-outline-light btn-sm">
                <i class="fa fa-list me-1"></i>Mes enchères
            </a>
            <span class="text-white-50 small">
                <i class="fa fa-user-circle me-1"></i>
                <?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?>
            </span>
            <a href="?module=auth&action=logout" class="btn btn-outline-light btn-sm">
                <i class="fa fa-right-from-bracket"></i>
            </a>
        </div>
    </div>
</nav>

<div class="hero text-center">
    <h1 class="fw-bold mb-2"><i class="fa fa-gavel me-2"></i>Investir dans l'artisanat tunisien</h1>
    <p class="opacity-75 mb-0">Soutenez des projets authentiques et participez à la préservation du patrimoine</p>
</div>

<div class="container py-5">

    <?php if (!empty($flash)): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mb-4">
            <?= htmlspecialchars($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold mb-0">
            Projets ouverts
            <span class="badge ms-2" style="background:var(--g)"><?= count($projets) ?></span>
        </h5>
    </div>

    <?php if (empty($projets)): ?>
        <div class="empty-state">
            <i class="fa fa-folder-open fa-4x text-muted mb-3"></i>
            <p class="text-muted fs-5">Aucun projet disponible pour le moment.</p>
        </div>
    <?php else: ?>

    <div class="row g-4">
        <?php foreach ($projets as $p):
            $highest   = (float)$p['meilleure_offre'];
            $bmin      = (float)$p['budget_min'];
            $pct       = $bmin > 0 ? min(100, round(($highest / $bmin) * 100)) : 0;
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="card card-projet h-100">
                <div class="top-bar"></div>
                <div class="card-body p-4 d-flex flex-column">

                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 class="card-title fw-bold mb-0" style="font-size:1rem">
                            <?= htmlspecialchars($p['titre']) ?>
                        </h5>
                        <?php if ($p['categorie_nom']): ?>
                            <span class="badge-cat ms-2 text-nowrap"><?= htmlspecialchars($p['categorie_nom']) ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <div class="text-muted small mb-1">Budget minimum requis</div>
                        <div class="montant-min"><?= number_format($bmin, 0, ',', ' ') ?> <span class="fs-6 fw-normal text-muted">TND</span></div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between small text-muted mb-1">
                            <span>Meilleure offre</span>
                            <span class="fw-semibold text-dark">
                                <?= $highest > 0 ? number_format($highest, 0, ',', ' ') . ' TND' : 'Aucune offre' ?>
                            </span>
                        </div>
                        <div class="progress" style="height:7px;border-radius:4px;">
                            <div class="progress-bar" role="progressbar" style="width:<?= $pct ?>%"></div>
                        </div>
                        <div class="text-end small text-muted mt-1"><?= $pct ?>% du budget atteint</div>
                    </div>

                    <div class="text-muted small mb-4">
                        <i class="fa fa-users me-1"></i><?= $p['nb_encheres'] ?> enchère(s) &nbsp;|&nbsp;
                        <i class="fa fa-calendar me-1"></i><?= date('d/m/Y', strtotime($p['date_creation'])) ?>
                    </div>

                    <div class="mt-auto">
                        <a href="?module=investissement&action=form&id_projet=<?= $p['id'] ?>"
                           class="btn btn-encherer w-100">
                            <i class="fa fa-gavel me-2"></i>Enchérir sur ce projet
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
