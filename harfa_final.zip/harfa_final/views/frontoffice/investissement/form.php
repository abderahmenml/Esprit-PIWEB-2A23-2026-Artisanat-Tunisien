<?php
/**
 * =========================================================================
 *  حرفة Tunisie — FrontOffice - Formulaire de Soumission d'Enchère
 * =========================================================================
 * Affiche un formulaire complet pour soumettre une enchère avec :
 * - Validation JavaScript en temps réel
 * - Validation PHP côté serveur (double check)
 * - Messages d'erreur et de succès
 * - Indicateur de montant minimum requis
 * 
 * Variables disponibles (passées depuis le contrôleur):
 *   $projet       : Détails du projet courant
 *   $id_projet    : ID du projet
 *   $budget_min   : Budget minimum du projet
 *   $highest_bid  : Meilleure offre actuelle
 *   $errors       : Errors de validation
 *   $old          : Valeurs saisies avant erreur
 *   $flash        : Messages de notification
 */
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Soumettre une enchère — حرفة Tunisie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --p:#8B4513; --g:#C9933A; --bg:#FDF6EC; }
        body { background:var(--bg); font-family:'Segoe UI',sans-serif; }
        .navbar-harfa { background:var(--p); }
        .form-wrapper { max-width:640px; margin:2.5rem auto; }
        .form-card { border:none; border-radius:18px; box-shadow:0 8px 32px rgba(0,0,0,.1); overflow:hidden; }
        .form-header { background:linear-gradient(135deg,var(--p),var(--g)); color:#fff; padding:1.8rem 2rem; }
        .form-body { background:#fff; padding:2rem; }
        .info-banner { background:#fff8f0; border-left:4px solid var(--g); border-radius:0 8px 8px 0; padding:1rem 1.2rem; }
        .form-control:focus { border-color:var(--g); box-shadow:0 0 0 .2rem rgba(201,147,58,.2); }
        .btn-submit { background:var(--p); color:#fff; font-weight:700; border-radius:10px; padding:.8rem; font-size:1.05rem; }
        .btn-submit:hover { background:var(--g); color:#fff; }
        .char-counter { font-size:.77rem; }
        .feedback-ok  { color:#198754; font-size:.8rem; }
        .feedback-err { color:#dc3545; font-size:.8rem; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark navbar-harfa">
    <div class="container">
        <a class="navbar-brand fw-bold" href="?module=investissement&action=liste">
            حرفة <span style="color:var(--g)">Tunisie</span>
        </a>
        <div class="d-flex gap-2">
            <a href="?module=investissement&action=liste" class="btn btn-outline-light btn-sm">
                <i class="fa fa-arrow-left me-1"></i>Retour
            </a>
            <a href="?module=auth&action=logout" class="btn btn-outline-light btn-sm">
                <i class="fa fa-right-from-bracket"></i>
            </a>
        </div>
    </div>
</nav>

<div class="container">
<div class="form-wrapper">

    <?php if (!empty($flash)): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mt-3">
            <?= htmlspecialchars($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="form-card mt-4">
        <div class="form-header">
            <h4 class="fw-bold mb-1"><i class="fa fa-gavel me-2"></i>Soumettre une enchère</h4>
            <?php if ($projet): ?>
                <div class="opacity-80 small">Projet : <?= htmlspecialchars($projet['titre']) ?></div>
            <?php endif; ?>
        </div>

        <div class="form-body">

            <!-- Infos enchère -->
            <div class="info-banner mb-4">
                <div class="row g-3">
                    <div class="col-6">
                        <div class="text-muted small">Budget minimum</div>
                        <div class="fw-bold fs-5" style="color:var(--p)"><?= number_format($budget_min, 0, ',', ' ') ?> TND</div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted small">Enchère actuelle la + haute</div>
                        <div class="fw-bold fs-5" style="color:var(--g)">
                            <?= $highest_bid > 0 ? number_format($highest_bid, 0, ',', ' ') . ' TND' : '<span class="text-muted fw-normal">Aucune</span>' ?>
                        </div>
                    </div>
                </div>
                <div class="small text-muted mt-2">
                    <i class="fa fa-arrow-right me-1"></i>
                    Votre offre doit dépasser
                    <strong><?= number_format(max($budget_min, $highest_bid), 0, ',', ' ') ?> TND</strong>
                </div>
            </div>

            <!-- Erreur globale -->
            <?php if (!empty($errors['global'])): ?>
                <div class="alert alert-danger">
                    <i class="fa fa-circle-exclamation me-2"></i>
                    <?= htmlspecialchars($errors['global']) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="?module=investissement&action=add" id="frmEnchere" novalidate>
                <input type="hidden" name="id_projet" value="<?= (int)$id_projet ?>">

                <!-- Montant -->
                <div class="mb-4">
                    <label for="montant" class="form-label fw-semibold">
                        Montant de l'offre (TND) <span class="text-danger">*</span>
                    </label>
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="fa fa-coins" style="color:var(--g)"></i></span>
                        <input type="text" id="montant" name="montant"
                               class="form-control <?= isset($errors['montant']) ? 'is-invalid' : '' ?>"
                               value="<?= htmlspecialchars($old['montant'] ?? '') ?>"
                               placeholder="Ex: <?= (int)($budget_min * 1.1) ?>"
                               autocomplete="off">
                        <span class="input-group-text bg-white text-muted fw-bold">TND</span>
                    </div>
                    <?php if (!empty($errors['montant'])): ?>
                        <div class="feedback-err mt-1"><i class="fa fa-circle-xmark me-1"></i><?= htmlspecialchars($errors['montant']) ?></div>
                    <?php endif; ?>
                    <div id="montant-err" class="feedback-err mt-1" style="display:none"></div>
                    <div id="montant-ok"  class="feedback-ok  mt-1" style="display:none"><i class="fa fa-check-circle me-1"></i>Montant valide ✓</div>
                </div>

                <!-- Message -->
                <div class="mb-4">
                    <label for="message" class="form-label fw-semibold">
                        Message de motivation <span class="text-danger">*</span>
                    </label>
                    <textarea id="message" name="message" rows="5"
                              class="form-control <?= isset($errors['message']) ? 'is-invalid' : '' ?>"
                              placeholder="Expliquez pourquoi vous investissez dans ce projet (min. 20 caractères)..."><?= htmlspecialchars($old['message'] ?? '') ?></textarea>
                    <div class="d-flex justify-content-between mt-1">
                        <div>
                            <?php if (!empty($errors['message'])): ?>
                                <div class="feedback-err"><i class="fa fa-circle-xmark me-1"></i><?= htmlspecialchars($errors['message']) ?></div>
                            <?php endif; ?>
                            <div id="msg-err" class="feedback-err" style="display:none"></div>
                        </div>
                        <span class="char-counter text-muted">
                            <span id="char-now">0</span> / 20 min
                        </span>
                    </div>
                </div>

                <!-- Actions -->
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-submit" id="btnSubmit">
                        <i class="fa fa-paper-plane me-2"></i>Soumettre mon enchère
                    </button>
                    <a href="?module=investissement&action=liste" class="btn btn-outline-secondary">Annuler</a>
                </div>
            </form>
        </div>
    </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const BUDGET_MIN  = <?= (float)$budget_min ?>;
const HIGHEST_BID = <?= (float)$highest_bid ?>;
const SEUIL       = Math.max(BUDGET_MIN, HIGHEST_BID);

const elMontant  = document.getElementById('montant');
const elMessage  = document.getElementById('message');
const errMontant = document.getElementById('montant-err');
const okMontant  = document.getElementById('montant-ok');
const errMsg     = document.getElementById('msg-err');
const elCharNow  = document.getElementById('char-now');

function validateMontant() {
    const v = elMontant.value.trim();
    errMontant.style.display = 'none';
    okMontant.style.display  = 'none';
    elMontant.classList.remove('is-valid','is-invalid');

    if (!v) {
        elMontant.classList.add('is-invalid');
        errMontant.textContent = 'Le montant est obligatoire.';
        errMontant.style.display = 'block';
        return false;
    }
    if (isNaN(v) || Number(v) <= 0) {
        elMontant.classList.add('is-invalid');
        errMontant.textContent = 'Entrez un nombre positif.';
        errMontant.style.display = 'block';
        return false;
    }
    if (Number(v) < BUDGET_MIN) {
        elMontant.classList.add('is-invalid');
        errMontant.textContent = `Doit être ≥ au budget minimum (${BUDGET_MIN.toLocaleString('fr-FR')} TND).`;
        errMontant.style.display = 'block';
        return false;
    }
    if (HIGHEST_BID > 0 && Number(v) <= HIGHEST_BID) {
        elMontant.classList.add('is-invalid');
        errMontant.textContent = `Doit dépasser l'enchère actuelle (${HIGHEST_BID.toLocaleString('fr-FR')} TND).`;
        errMontant.style.display = 'block';
        return false;
    }
    elMontant.classList.add('is-valid');
    okMontant.style.display = 'block';
    return true;
}

function validateMessage() {
    const txt = elMessage.value.trim();
    elCharNow.textContent = txt.length;
    errMsg.style.display  = 'none';
    elMessage.classList.remove('is-valid','is-invalid');

    if (txt.length < 20) {
        elMessage.classList.add('is-invalid');
        errMsg.textContent    = `Trop court : ${txt.length}/20 caractères minimum.`;
        errMsg.style.display  = 'block';
        elCharNow.style.color = '#dc3545';
        return false;
    }
    elMessage.classList.add('is-valid');
    elCharNow.style.color = '#198754';
    return true;
}

elMontant.addEventListener('input', validateMontant);
elMessage.addEventListener('input', validateMessage);

document.getElementById('frmEnchere').addEventListener('submit', function(e) {
    const ok = validateMontant() & validateMessage();
    if (!ok) {
        e.preventDefault();
        document.querySelector('.is-invalid')?.scrollIntoView({behavior:'smooth', block:'center'});
    }
});

// Pré-remplissage après erreur PHP
if (elMessage.value.trim().length) validateMessage();
if (elMontant.value.trim().length) validateMontant();
</script>
</body>
</html>
