<?php
// index.php  — Point d'entrée unique (Front Controller)

session_start();

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/EnchereController.php';

$pdo = getDBConnection();

$module = $_GET['module'] ?? 'auth';
$action = $_GET['action'] ?? 'login';

// Routing principal
switch ($module) {
    case 'auth':
        (new AuthController($pdo))->dispatch($action);
        break;

    case 'investissement':
        (new EnchereController($pdo))->dispatch($action);
        break;

    default:
        header('Location: ?module=auth&action=login');
        exit;
}
