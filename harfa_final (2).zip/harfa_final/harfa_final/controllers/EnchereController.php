<?php
/**
 * =========================================================================
 *  حرفة Tunisie — Controller ENCHERE
 *  Gestion des actions pour les enchères (FrontOffice + BackOffice)
 * =========================================================================
 * Ce contrôleur gère :
 * - FrontOffice : Liste projets, formulaire enchère, mes enchères
 * - BackOffice  : Dashboard, accepter/refuser enchères
 * Comprend validation PHP et gestion des messages flash
 */

require_once __DIR__ . '/../models/Enchere.php';

class EnchereController
{
    /**
     * @var Enchere Instance du model Enchere
     */
    private Enchere $model;

    /**
     * __construct - Initialise le contrôleur
     * 
     * @param PDO $pdo Instance de connexion à la base de données
     */
    public function __construct(PDO $pdo)
    {
        $this->model = new Enchere($pdo);
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    /**
      * dispatch - Aiguille les actions vers les méthodes appropriées
    * Actions disponibles : index, liste, form, add, mes_encheres, forum,
    * add_avis, update_avis, delete_avis, generate_message, accept, refuse, delete
     * 
     * @param string $action Nom de l'action à exécuter
     */
    public function dispatch(string $action): void
    {
        match ($action) {
            // BackOffice - Gestion admin
            'index'        => $this->dashboardEncheres(),
            'accept'       => $this->accepterEnchere(),
            'refuse'       => $this->refuserEnchere(),
            'delete'       => $this->supprimerEnchere(),
            
            // FrontOffice - Investisseurs
            'liste'        => $this->listerProjets(),
            'form'         => $this->formulaireEnchere(),
            'add'          => $this->ajouterEnchere(),
            'mes_encheres' => $this->mesEncheres(),
            'forum'        => $this->forumEncheres(),
            'add_avis'     => $this->ajouterAvisEnchere(),
            'update_avis'  => $this->modifierAvisEnchere(),
            'delete_avis'  => $this->supprimerAvisEnchere(),
            'generate_message' => $this->genererMessageIA(),
            'analyse_ia'   => $this->analyserProjetsIA(),
            
            default        => $this->listerProjets(),
        };
    }

    // ═══════════════════════════════════════════════════════════════
    // BACKOFFICE - DASHBOARD ENCHÈRES
    // ═══════════════════════════════════════════════════════════════

    /**
     * dashboardEncheres - Affiche le dashboard d'administration des enchères
     * Inclus filtrage par projet, statut et date
     * Affiche aussi les statistiques globales
     * 
     * @return void Affiche la vue backoffice/investissement/index.php
     */
    private function dashboardEncheres(): void
    {
        // Vérifier que l'utilisateur est admin
        $this->requireRole('admin');

        // Récupérer toutes les enchères
        $encheres = $this->model->getAllEncheres();

        // ── FILTRAGE ────────────────────────────────────────────
        $idProjetFiltre = isset($_GET['projet']) ? (int)$_GET['projet'] : 0;
        $statutFiltre = $_GET['statut'] ?? '';
        $dateFiltre = $_GET['date'] ?? '';

        // Filtre par projet
        if ($idProjetFiltre) {
            $encheres = array_filter($encheres, fn($e) => $e['id_projet'] === $idProjetFiltre);
        }

        // Filtre par statut (en_attente, acceptee, refusee)
        if ($statutFiltre && in_array($statutFiltre, ['en_attente', 'acceptee', 'refusee'])) {
            $encheres = array_filter($encheres, fn($e) => $e['statut'] === $statutFiltre);
        }

        // Filtre par date (format YYYY-MM-DD)
        if ($dateFiltre) {
            $encheres = array_filter($encheres, fn($e) => 
                substr($e['date_enchere'], 0, 10) === $dateFiltre
            );
        }

        // ── STATISTIQUES ────────────────────────────────────────
        $stats = [
            'total'     => $this->model->countTotal(),
            'montant'   => $this->model->sumMontantAccepte(),
            'finances'  => $this->model->countProjetsFinances(),
        ];

        // Récupérer les messages flash
        $flash = $this->getFlash();

        // Charger la vue
        require_once __DIR__ . '/../views/backoffice/investissement/index.php';
    }

    /**
     * accepterEnchere - Accepte une enchère (passage au statut 'acceptee')
     * 
     * @return void Redirige vers le dashboard
     */
    private function accepterEnchere(): void
    {
        $this->requireRole('admin');
        $this->requirePost();

        $id = (int)($_POST['id'] ?? 0);

        if ($id && $this->model->updateStatut($id, 'acceptee')) {
            $this->setFlash('success', '✓ Enchère acceptée avec succès !');
        } else {
            $this->setFlash('error', '❌ Erreur : impossible d\'accepter cette enchère.');
        }

        header('Location: ?module=investissement&action=index');
        exit;
    }

    /**
     * refuserEnchere - Refuse une enchère (passage au statut 'refusee')
     * 
     * @return void Redirige vers le dashboard
     */
    private function refuserEnchere(): void
    {
        $this->requireRole('admin');
        $this->requirePost();

        $id = (int)($_POST['id'] ?? 0);

        if ($id && $this->model->updateStatut($id, 'refusee')) {
            $this->setFlash('success', '✓ Enchère refusée avec succès.');
        } else {
            $this->setFlash('error', '❌ Erreur : impossible de refuser cette enchère.');
        }

        header('Location: ?module=investissement&action=index');
        exit;
    }

    /**
     * supprimerEnchere - Supprime une enchère de la base de données
     * 
     * @return void Redirige vers le dashboard
     */
    private function supprimerEnchere(): void
    {
        $this->requireRole('admin');
        $this->requirePost();

        $id = (int)($_POST['id'] ?? 0);

        if ($id && $this->model->deleteEnchere($id)) {
            $this->setFlash('success', '✓ Enchère supprimée.');
        } else {
            $this->setFlash('error', '❌ Erreur : suppression impossible.');
        }

        header('Location: ?module=investissement&action=index');
        exit;
    }

    // ═══════════════════════════════════════════════════════════════
    // FRONTOFFICE - GESTION DES ENCHÈRES  
    // ═══════════════════════════════════════════════════════════════

    /**
     * listerProjets - Affiche la liste des projets ouverts aux enchères
     * Inclus informations : titre, budget minimum, meilleure offre, nombre d'enchères
     * 
     * @return void Affiche la vue frontoffice/investissement/liste.php
     */
    private function listerProjets(): void
    {
        // Vérifier que l'utilisateur est connecté
        $this->requireAuth();

        // Récupérer les projets ouverts avec stats
        $projets = $this->model->getProjetsOuverts();

        // Récupérer les messages flash
        $flash = $this->getFlash();

        // Charger la vue
        require_once __DIR__ . '/../views/frontoffice/investissement/liste.php';
    }

    /**
     * formulaireEnchere - Affiche le formulaire pour soumettre une enchère
     * Renforce avec validation JavaScript et PHP du côté serveur
     * 
     * @return void Affiche la vue frontoffice/investissement/form.php
     */
    private function formulaireEnchere(): void
    {
        // Vérifier que l'utilisateur est un investisseur
        $this->requireRole('investisseur');

        // Récupérer l'ID du projet depuis GET ou POST
        // Fallback sur "id" pour compatibilité avec d'autres liens éventuels.
        $idProjet = (int)($_GET['id_projet'] ?? $_POST['id_projet'] ?? $_GET['id'] ?? $_POST['id'] ?? 0);

        // Vérifier que l'ID du projet est valide
        if (!$idProjet) {
            $this->setFlash('error', '❌ Projet introuvable.');
            header('Location: ?module=investissement&action=liste');
            exit;
        }

        // Récupérer les détails du projet
        $projet = $this->model->getProjetById($idProjet);
        if (!$projet) {
            $this->setFlash('error', '❌ Projet introuvable.');
            header('Location: ?module=investissement&action=liste');
            exit;
        }

        // Initialiser les variables
        $errors = [];
        $old = [];
        $budget_min = $this->model->getBudgetMin($idProjet);
        $highest_bid = $this->model->getHighestBid($idProjet);
        $idUser = (int)$_SESSION['user']['id_user'];

        // ── TRAITEMENT DU FORMULAIRE ────────────────────────────
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $montant = trim($_POST['montant'] ?? '');
            $message = trim($_POST['message'] ?? '');

            // Sauvegarder les valeurs pour affichage en cas d'erreur
            $old = compact('montant', 'message');

            // ── VALIDATION PHP STRICTE ──────────────────────────

            // 1. Montant obligatoire et valide
            if ($montant === '') {
                $errors['montant'] = 'Le montant est obligatoire.';
            } elseif (!is_numeric($montant)) {
                $errors['montant'] = 'Le montant doit être un nombre valide.';
            } elseif ((float)$montant <= 0) {
                $errors['montant'] = 'Le montant doit être supérieur à 0 TND.';
            }
            // 2. Vérifier montant >= budget minimum
            elseif ((float)$montant < $budget_min) {
                $montantFormate = number_format($budget_min, 0, ',', ' ');
                $errors['montant'] = "Le montant minimum requis est {$montantFormate} TND.";
            }
            // 3. Vérifier montant > meilleure enchère existante
            elseif ($highest_bid > 0 && (float)$montant <= $highest_bid) {
                $montantFormate = number_format($highest_bid, 0, ',', ' ');
                $errors['montant'] = "Votre offre doit dépasser {$montantFormate} TND (meilleure offre actuelle).";
            }

            // 4. Message de motivation : minimum 20 caractères
            if (mb_strlen($message) < 20) {
                $longueur = mb_strlen($message);
                $errors['message'] = "Le message doit contenir au moins 20 caractères (actuellement : {$longueur}).";
            }

            // 5. Vérifier que l'investisseur n'a pas déjà enchéri
            if ($this->model->hasAlreadyBid($idProjet, $idUser)) {
                $errors['global'] = '❌ Vous avez déjà soumis une enchère pour ce projet. Un investisseur = une enchère par projet.';
            }

            // ── INSERTION SI VALIDE ─────────────────────────────
            if (empty($errors)) {
                $success = $this->model->addEnchere($idProjet, $idUser, (float)$montant, $message);

                if ($success) {
                    $this->setFlash('success', '🎉 Votre enchère a été soumise avec succès !');
                    header('Location: ?module=investissement&action=mes_encheres');
                    exit;
                } else {
                    $errors['global'] = '⚠️ Une erreur serveur est survenue. Veuillez réessayer.';
                }
            }
        }

        // Récupérer les messages flash
        $flash = $this->getFlash();

        // Alias pour la vue (form.php attend $id_projet)
        $id_projet = $idProjet;

        // Charger la vue
        require_once __DIR__ . '/../views/frontoffice/investissement/form.php';
    }

    /**
     * ajouterEnchere - Alias pour formulaireEnchere (redirection POST)
     * Permet d'utiliser ?action=add ou ?action=form indifféremment
     * 
     * @return void Redirige vers formulaireEnchere()
     */
    private function ajouterEnchere(): void
    {
        $this->formulaireEnchere();
    }

    /**
     * mesEncheres - Affiche les enchères soumises par l'investisseur connecté
     * Inclus statut et détails de chaque enchère + projet
     * 
     * @return void Affiche la vue frontoffice/investissement/mes_encheres.php
     */
    private function mesEncheres(): void
    {
        // Vérifier que l'utilisateur est un investisseur
        $this->requireRole('investisseur');

        // Récupérer l'ID de l'investisseur depuis la session
        $idUser = (int)$_SESSION['user']['id_user'];

        // Récupérer ses enchères
        $encheres = $this->model->getEnchersByInvestisseur($idUser);

        // Récupérer les messages flash
        $flash = $this->getFlash();

        // Charger la vue
        require_once __DIR__ . '/../views/frontoffice/investissement/mes_encheres.php';
    }

    /**
     * forumEncheres - Affiche toutes les enchères avec les avis
     *
     * @return void
     */
    private function forumEncheres(): void
    {
        $this->requireAuth();

        $encheres = $this->model->getForumEncheres();
        $ids = array_map(fn($e) => (int)$e['id'], $encheres);
        $avisByEnchere = $this->model->getAvisByEnchereIds($ids);

        $flash = $this->getFlash();

        require_once __DIR__ . '/../views/frontoffice/investissement/forum.php';
    }

    /**
     * ajouterAvisEnchere - Enregistre un avis sur une enchère depuis la page forum
     *
     * @return void
     */
    private function ajouterAvisEnchere(): void
    {
        $this->requireAuth();
        $this->requirePost();

        $idEnchere = (int)($_POST['id_enchere'] ?? 0);
        $note = (int)($_POST['note'] ?? 0);
        $commentaire = trim($_POST['commentaire'] ?? '');
        $idUser = (int)$_SESSION['user']['id_user'];

        if ($idEnchere <= 0 || $note < 1 || $note > 5 || $commentaire === '') {
            $this->setFlash('error', '❌ Données avis invalides.');
            header('Location: ?module=investissement&action=forum');
            exit;
        }

        if ($this->model->addAvisEnchere($idEnchere, $idUser, $commentaire, $note)) {
            $this->setFlash('success', '✅ Avis ajouté avec succès.');
        } else {
            $this->setFlash('error', '❌ Impossible d\'ajouter cet avis.');
        }

        header('Location: ?module=investissement&action=forum');
        exit;
    }

    /**
     * modifierAvisEnchere - Met à jour un avis existant
     *
     * @return void
     */
    private function modifierAvisEnchere(): void
    {
        $this->requireAuth();
        $this->requirePost();

        $idAvis = (int)($_POST['id_avis_enchere'] ?? 0);
        $note = (int)($_POST['note'] ?? 0);
        $commentaire = trim($_POST['commentaire'] ?? '');
        $idUser = (int)$_SESSION['user']['id_user'];

        if ($idAvis <= 0 || $note < 1 || $note > 5 || $commentaire === '') {
            $this->setFlash('error', '❌ Données de modification invalides.');
            header('Location: ?module=investissement&action=forum');
            exit;
        }

        if ($this->model->updateAvisEnchere($idAvis, $idUser, $commentaire, $note)) {
            $this->setFlash('success', '✅ Avis modifié avec succès.');
        } else {
            $this->setFlash('error', '❌ Impossible de modifier cet avis.');
        }

        header('Location: ?module=investissement&action=forum');
        exit;
    }

    /**
     * supprimerAvisEnchere - Supprime un avis existant
     *
     * @return void
     */
    private function supprimerAvisEnchere(): void
    {
        $this->requireAuth();
        $this->requirePost();

        $idAvis = (int)($_POST['id_avis_enchere'] ?? 0);
        $idUser = (int)$_SESSION['user']['id_user'];

        if ($idAvis <= 0) {
            $this->setFlash('error', '❌ Avis introuvable.');
            header('Location: ?module=investissement&action=forum');
            exit;
        }

        if ($this->model->deleteAvisEnchere($idAvis, $idUser)) {
            $this->setFlash('success', '✅ Avis supprimé avec succès.');
        } else {
            $this->setFlash('error', '❌ Impossible de supprimer cet avis.');
        }

        header('Location: ?module=investissement&action=forum');
        exit;
    }

    /**
     * genererMessageIA - Génère un message de motivation dédié au projet via Groq
     *
     * @return void JSON {message: string} ou {error: string}
     */
    private function genererMessageIA(): void
    {
        $this->requireRole('investisseur');
        $this->requirePost();

        header('Content-Type: application/json; charset=utf-8');

        $idProjet = (int)($_POST['id_projet'] ?? 0);
        if ($idProjet <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'ID projet invalide.']);
            return;
        }

        $projet = $this->model->getProjetById($idProjet);
        if (!$projet) {
            http_response_code(404);
            echo json_encode(['error' => 'Projet introuvable.']);
            return;
        }

        $apiKey = getenv('GROQ_API_KEY')
            ?: ($_ENV['GROQ_API_KEY'] ?? $_SERVER['GROQ_API_KEY'] ?? '')
            ?: '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';
        if ($apiKey === '') {
            http_response_code(500);
            echo json_encode(['error' => 'Clé API Groq non configurée. Ajoutez GROQ_API_KEY dans l\'environnement.']);
            return;
        }

        $budgetMin = (float)$this->model->getBudgetMin($idProjet);
        $highestBid = (float)$this->model->getHighestBid($idProjet);

        $payload = [
            'model' => 'llama-3.3-70b-versatile',
            'temperature' => 0.7,
            'max_tokens' => 220,
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'Tu es un assistant qui rédige des messages de motivation pour des investisseurs. Réponds en français, ton professionnel, clair, convaincant. Entre 60 et 120 mots.'
                ],
                [
                    'role' => 'user',
                    'content' => 'Rédige un message de motivation pour une enchère sur ce projet: ' .
                        'Titre: ' . ($projet['titre'] ?? 'Projet') . '. ' .
                        'Budget minimum: ' . number_format($budgetMin, 0, ',', ' ') . ' TND. ' .
                        'Meilleure enchère actuelle: ' . number_format($highestBid, 0, ',', ' ') . ' TND. ' .
                        'Le message doit montrer engagement, valeur apportée, et vision long terme.'
                ]
            ]
        ];

        $ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT => 30,
        ]);

        $response = curl_exec($ch);
        $curlErr = curl_error($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $curlErr) {
            http_response_code(502);
            echo json_encode(['error' => 'Erreur d\'appel Groq: ' . $curlErr]);
            return;
        }

        $data = json_decode($response, true);
        if ($httpCode >= 400 || !is_array($data)) {
            http_response_code(502);
            echo json_encode(['error' => 'Réponse Groq invalide.']);
            return;
        }

        $message = trim((string)($data['choices'][0]['message']['content'] ?? ''));
        if ($message === '') {
            http_response_code(502);
            echo json_encode(['error' => 'Aucun message généré.']);
            return;
        }

        echo json_encode(['message' => $message], JSON_UNESCAPED_UNICODE);
    }

    // ═══════════════════════════════════════════════════════════════
    // ANALYSE IA DES PROJETS VIA GEMINI
    // ═══════════════════════════════════════════════════════════════

    /**
     * analyserProjetsIA - Analyse tous les projets ouverts avec Gemini
     * et recommande le meilleur projet pour enchérir.
     *
     * @return void JSON {analyse: string, meilleur_projet: array} ou {error: string}
     */
    private function analyserProjetsIA(): void
    {
        $this->requireAuth();
        $this->requirePost();

        header('Content-Type: application/json; charset=utf-8');

        // Récupérer tous les projets ouverts
        $projets = $this->model->getProjetsOuverts();

        if (empty($projets)) {
            http_response_code(404);
            echo json_encode(['error' => 'Aucun projet ouvert disponible pour analyse.']);
            return;
        }

        // Construire le résumé des projets pour Gemini
        $resumeProjets = '';
        foreach ($projets as $i => $p) {
            $num        = $i + 1;
            $titre      = htmlspecialchars_decode($p['titre'] ?? 'N/A');
            $categorie  = $p['categorie_nom'] ?? 'Non catégorisé';
            $budgetMin  = number_format((float)$p['budget_min'], 0, ',', ' ');
            $meilleureO = number_format((float)$p['meilleure_offre'], 0, ',', ' ');
            $nbEncheres = (int)$p['nb_encheres'];
            $pct        = $p['budget_min'] > 0
                ? min(100, round(((float)$p['meilleure_offre'] / (float)$p['budget_min']) * 100))
                : 0;
            $date       = date('d/m/Y', strtotime($p['date_creation']));

            $resumeProjets .= "Projet {$num}: {$titre}\n";
            $resumeProjets .= "  - Catégorie: {$categorie}\n";
            $resumeProjets .= "  - Budget minimum requis: {$budgetMin} TND\n";
            $resumeProjets .= "  - Meilleure offre actuelle: {$meilleureO} TND\n";
            $resumeProjets .= "  - Nombre d'enchères: {$nbEncheres}\n";
            $resumeProjets .= "  - Financement atteint: {$pct}%\n";
            $resumeProjets .= "  - Date de création: {$date}\n\n";
        }

        $geminiKey = 'AIzaSyC6SdAfXENxDEgFZHQbVw89C5BwAq1HMUs';
        $geminiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

        $prompt = "Tu es un expert en investissement dans l'artisanat tunisien. "
            . "Voici la liste des projets actuellement ouverts aux enchères sur la plateforme حرفة Tunisie :\n\n"
            . $resumeProjets
            . "Analyse chaque projet en détail selon ces critères :\n"
            . "1. Potentiel de retour sur investissement\n"
            . "2. Popularité et intérêt des investisseurs (nombre d'enchères)\n"
            . "3. Niveau de financement atteint vs budget requis\n"
            . "4. Catégorie artisanale et son potentiel culturel et économique\n\n"
            . "Ensuite, recommande clairement LE MEILLEUR PROJET sur lequel enchérir, en justifiant ton choix. "
            . "Fournis une analyse structurée avec des sections claires. Réponds en français. "
            . "Format de ta réponse :\n"
            . "## 📊 Analyse des Projets\n[analyse détaillée de chaque projet]\n\n"
            . "## 🏆 Recommandation\n[nom du meilleur projet et justification détaillée]\n\n"
            . "## 💡 Conseils d'Investissement\n[3 conseils pratiques pour l'investisseur]";

        $payload = [
            'contents' => [
                [
                    'role' => 'user',
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature'     => 0.7,
                'maxOutputTokens' => 2048,
            ]
        ];

        $ch = curl_init($geminiUrl . '?key=' . $geminiKey);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT        => 60,
        ]);

        $response = curl_exec($ch);
        $curlErr  = curl_error($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $curlErr) {
            http_response_code(502);
            echo json_encode(['error' => 'Erreur de connexion à Gemini: ' . $curlErr]);
            return;
        }

        $data = json_decode($response, true);

        if ($httpCode >= 400 || !is_array($data)) {
            http_response_code(502);
            echo json_encode(['error' => 'Réponse Gemini invalide (code: ' . $httpCode . ').']);
            return;
        }

        $analyse = trim((string)($data['candidates'][0]['content']['parts'][0]['text'] ?? ''));

        if ($analyse === '') {
            http_response_code(502);
            echo json_encode(['error' => 'Aucune analyse générée par Gemini.']);
            return;
        }

        // Identifier le meilleur projet mentionné dans la réponse
        $meilleurProjet = null;
        foreach ($projets as $p) {
            if (stripos($analyse, $p['titre']) !== false) {
                // Chercher dans la section Recommandation
                $posReco = stripos($analyse, '## 🏆 Recommandation');
                if ($posReco !== false) {
                    $sectionReco = substr($analyse, $posReco);
                    if (stripos($sectionReco, $p['titre']) !== false) {
                        $meilleurProjet = $p;
                        break;
                    }
                }
            }
        }

        // Fallback: prendre le projet avec le plus d'enchères
        if (!$meilleurProjet && !empty($projets)) {
            usort($projets, fn($a, $b) => (int)$b['nb_encheres'] - (int)$a['nb_encheres']);
            $meilleurProjet = $projets[0];
        }

        echo json_encode([
            'analyse'         => $analyse,
            'meilleur_projet' => $meilleurProjet,
            'nb_projets'      => count($projets),
        ], JSON_UNESCAPED_UNICODE);
    }

    // ═══════════════════════════════════════════════════════════════
    // HELPERS - UTILITAIRES
    // ═══════════════════════════════════════════════════════════════

    /**
     * requireAuth - Vérifie que l'utilisateur est connecté
     * Redirige vers login si non connecté
     * 
     * @return void
     */
    private function requireAuth(): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: ?module=auth&action=login');
            exit;
        }
    }

    /**
     * requireRole - Vérifie que l'utilisateur a le rôle requis
     * Redirige vers login ou liste si accès non autorisé
     * 
     * @param string $role Rôle requis ('admin', 'investisseur', 'entrepreneur', etc.)
     * @return void
     */
    private function requireRole(string $role): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: ?module=auth&action=login');
            exit;
        }

        if ($_SESSION['user']['role'] !== $role) {
            header('Location: ?module=investissement&action=liste');
            exit;
        }
    }

    /**
     * requirePost - Vérifie que la requête est une POST
     * Utile pour les actions critiques (delete, update, insert)
     * 
     * @return void
     */
    private function requirePost(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ?module=investissement&action=index');
            exit;
        }
    }

    /**
     * setFlash - Enregistre un message flash en session
     * Messages flash : affichés une seule fois puis supprimés
     * 
     * @param string $type Type de message : 'success', 'error', 'info', 'warning'
     * @param string $msg  Contenu du message
     * @return void
     */
    private function setFlash(string $type, string $msg): void
    {
        $_SESSION['flash'] = [
            'type'    => $type,
            'message' => $msg
        ];
    }

    /**
     * getFlash - Récupère et vide le message flash
     * 
     * @return array Array vide [] ou ['type' => 'xxx', 'message' => 'yyy']
     */
    private function getFlash(): array
    {
        $flash = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $flash;
    }
}
