<?php
/**
 * =========================================================================
 *  Harfa Tunisie - Controller AVIS (BackOffice)
 * =========================================================================
 */

require_once __DIR__ . '/../models/Avis.php';

class AvisController
{
    private Avis $model;

    public function __construct(PDO $pdo)
    {
        $this->model = new Avis($pdo);
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    public function dispatch(string $action): void
    {
        match ($action) {
            'index'  => $this->gestionAvisAdmin(),
            'delete' => $this->supprimerAvisAdmin(),
            default  => $this->gestionAvisAdmin(),
        };
    }

    private function gestionAvisAdmin(): void
    {
        $this->requireRole('admin');

        $filters = [
            'id_enchere' => (int)($_GET['id_enchere'] ?? 0),
            'note'       => (int)($_GET['note'] ?? 0),
            'q'          => trim($_GET['q'] ?? ''),
            'date_debut' => trim($_GET['date_debut'] ?? ''),
            'date_fin'   => trim($_GET['date_fin'] ?? ''),
        ];

        $avis_encheres_all = $this->model->getAllAvisEncheres(1500);
        $enchere_options = $this->model->getEnchereOptionsForAvis();

        $avis_encheres = array_filter($avis_encheres_all, function ($a) use ($filters) {
            if ($filters['id_enchere'] > 0 && (int)$a['id_enchere'] !== $filters['id_enchere']) {
                return false;
            }

            if ($filters['note'] > 0 && (int)$a['note'] !== $filters['note']) {
                return false;
            }

            if ($filters['q'] !== '') {
                $needle = mb_strtolower($filters['q']);
                $haystack = mb_strtolower(
                    ($a['commentaire'] ?? '') . ' ' .
                    ($a['projet_titre'] ?? '') . ' ' .
                    ($a['prenom'] ?? '') . ' ' .
                    ($a['nom'] ?? '')
                );
                if (!str_contains($haystack, $needle)) {
                    return false;
                }
            }

            if ($filters['date_debut'] !== '' && substr((string)$a['created_at'], 0, 10) < $filters['date_debut']) {
                return false;
            }

            if ($filters['date_fin'] !== '' && substr((string)$a['created_at'], 0, 10) > $filters['date_fin']) {
                return false;
            }

            return true;
        });

        $avis_encheres = array_values($avis_encheres);

        $stats_avis = [
            'total' => count($avis_encheres),
            'note_1' => 0,
            'note_2' => 0,
            'note_3' => 0,
            'note_4' => 0,
            'note_5' => 0,
        ];

        foreach ($avis_encheres as $a) {
            $n = (int)$a['note'];
            if ($n >= 1 && $n <= 5) {
                $stats_avis['note_' . $n]++;
            }
        }

        $flash = $this->getFlash();
        require_once __DIR__ . '/../views/backoffice/investissement/avis.php';
    }

    private function supprimerAvisAdmin(): void
    {
        $this->requireRole('admin');
        $this->requirePost();

        $idAvis = (int)($_POST['id_avis_enchere'] ?? 0);

        if ($idAvis <= 0) {
            $this->setFlash('error', '❌ Avis introuvable.');
            header('Location: ?module=avis&action=index');
            exit;
        }

        if ($this->model->deleteAvisByAdmin($idAvis)) {
            $this->setFlash('success', '✅ Avis supprimé par l\'admin.');
        } else {
            $this->setFlash('error', '❌ Impossible de supprimer cet avis.');
        }

        header('Location: ?module=avis&action=index');
        exit;
    }

    private function requireRole(string $role): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: ?module=auth&action=login');
            exit;
        }

        if (($_SESSION['user']['role'] ?? '') !== $role) {
            header('Location: ?module=investissement&action=index');
            exit;
        }
    }

    private function requirePost(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            header('Location: ?module=avis&action=index');
            exit;
        }
    }

    private function setFlash(string $type, string $msg): void
    {
        $_SESSION['flash'] = [
            'type' => $type,
            'message' => $msg,
        ];
    }

    private function getFlash(): array
    {
        $flash = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $flash;
    }
}
