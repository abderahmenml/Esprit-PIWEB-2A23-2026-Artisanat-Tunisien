<?php
// controllers/AuthController.php

require_once __DIR__ . '/../models/User.php';

class AuthController
{
    private User $model;

    public function __construct(PDO $pdo)
    {
        $this->model = new User($pdo);
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    public function dispatch(string $action): void
    {
        match ($action) {
            'login'  => $this->login(),
            'logout' => $this->logout(),
            default  => $this->login(),
        };
    }

    private function login(): void
    {
        $errors = [];
        $old    = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email    = trim($_POST['email']    ?? '');
            $password = trim($_POST['password'] ?? '');
            $old      = compact('email');

            // Validation PHP (sans HTML5)
            if (empty($email)) {
                $errors['email'] = 'L\'adresse email est obligatoire.';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors['email'] = 'Format d\'email invalide.';
            }
            if (empty($password)) {
                $errors['password'] = 'Le mot de passe est obligatoire.';
            }

            if (empty($errors)) {
                $user = $this->model->findByEmail($email);
                if ($user && $this->model->verifyPassword($password, $user['mot_de_passe'])) {
                    $_SESSION['user'] = $user;
                    // Redirection selon le rôle
                    if ($user['role'] === 'admin') {
                        header('Location: ?module=investissement&action=index');
                    } else {
                        header('Location: ?module=investissement&action=liste');
                    }
                    exit;
                }
                $errors['global'] = 'Email ou mot de passe incorrect.';
            }
        }

        require_once __DIR__ . '/../views/auth/login.php';
    }

    private function logout(): void
    {
        session_destroy();
        header('Location: ?module=auth&action=login');
        exit;
    }
}
