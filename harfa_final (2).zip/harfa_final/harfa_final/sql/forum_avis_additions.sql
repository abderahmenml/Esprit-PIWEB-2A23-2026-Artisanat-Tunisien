-- ============================================================
-- Ajouts: Forum des encheres + avis sur enchere
-- Fichier additionnel (sans modifier database.sql)
-- ============================================================

USE harfa_tunisie;

CREATE TABLE IF NOT EXISTS avis_enchere (
    id_avis_enchere BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_enchere      BIGINT NOT NULL,
    id_user         BIGINT NOT NULL,
    commentaire     TEXT NOT NULL,
    note            INT NOT NULL,
    created_at      DATETIME DEFAULT NOW(),
    FOREIGN KEY (id_enchere) REFERENCES enchere(id) ON DELETE CASCADE,
    FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE CASCADE
);

CREATE INDEX idx_avis_enchere_id_enchere ON avis_enchere(id_enchere);
CREATE INDEX idx_avis_enchere_id_user ON avis_enchere(id_user);

-- Donnees de demo
INSERT INTO avis_enchere (id_enchere, id_user, commentaire, note, created_at) VALUES
(1, 2, 'Bonne enchere, le projet est interessant.', 4, NOW()),
(1, 3, 'Je soutiens cette initiative artisanale.', 5, NOW()),
(2, 2, 'Montant ambitieux mais realiste.', 4, NOW());
