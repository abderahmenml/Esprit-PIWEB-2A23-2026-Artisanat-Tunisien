-- ============================================================
--  حرفة Tunisie — Base de données complète
--  Module : Investissement (Système d'enchères)
-- ============================================================

CREATE DATABASE IF NOT EXISTS harfa_tunisie
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE harfa_tunisie;

-- ── Table : categorie ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categorie (
    id          BIGINT PRIMARY KEY AUTO_INCREMENT,
    nom         VARCHAR(100) NOT NULL,
    description TEXT
);

-- ── Table : user ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user (
    id_user       BIGINT PRIMARY KEY AUTO_INCREMENT,
    nom           VARCHAR(100) NOT NULL,
    prenom        VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe  VARCHAR(255) NOT NULL,
    role          ENUM('admin','investisseur','entrepreneur','artisan') DEFAULT 'investisseur',
    date_creation DATE DEFAULT (CURRENT_DATE),
    etat_compte   ENUM('actif','inactif','suspendu') DEFAULT 'actif'
);

-- ── Table : projet ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS projet (
    id             BIGINT PRIMARY KEY AUTO_INCREMENT,
    titre          VARCHAR(200) NOT NULL,
    budget_min     FLOAT        NOT NULL DEFAULT 0,
    status         ENUM('ouvert','ferme','finance') DEFAULT 'ouvert',
    date_creation  DATE DEFAULT (CURRENT_DATE),
    id_categorie   BIGINT,
    FOREIGN KEY (id_categorie) REFERENCES categorie(id) ON DELETE SET NULL
);

-- ── Table : enchere ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS enchere (
    id              BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_projet       BIGINT      NOT NULL,
    id_investisseur BIGINT      NOT NULL,
    montant         FLOAT       NOT NULL,
    message         TEXT,
    statut          ENUM('en_attente','acceptee','refusee') DEFAULT 'en_attente',
    date_enchere    DATETIME    DEFAULT NOW(),
    FOREIGN KEY (id_projet)       REFERENCES projet(id) ON DELETE CASCADE,
    FOREIGN KEY (id_investisseur) REFERENCES user(id_user) ON DELETE CASCADE
);

-- ── Données de démonstration ──────────────────────────────────

INSERT INTO categorie (nom, description) VALUES
('Poterie',        'Artisanat de la céramique et de l\'argile'),
('Tissage',        'Tapis, kilims et broderies traditionnelles'),
('Bijouterie',     'Joaillerie et parures artisanales'),
('Maroquinerie',   'Cuir et sellerie traditionnelle'),
('Vannerie',       'Paniers et objets en osier ou palmier');

-- Mot de passe pour tous : "password123" (hashé avec password_hash)
INSERT INTO user (nom, prenom, email, mot_de_passe, role, etat_compte) VALUES
('Admin',     'Système',   'admin@harfa.tn',      '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin',         'actif'),
('Ben Ali',   'Sami',      'sami@harfa.tn',        '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'investisseur',  'actif'),
('Trabelsi',  'Nadia',     'nadia@harfa.tn',       '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'investisseur',  'actif'),
('Mansouri',  'Karim',     'karim@harfa.tn',       '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'entrepreneur',  'actif');

INSERT INTO projet (titre, budget_min, status, date_creation, id_categorie) VALUES
('Atelier de poterie de Nabeul',         8000,  'ouvert',  '2025-03-01', 1),
('Tissage traditionnel de Gafsa',        12000, 'ouvert',  '2025-03-10', 2),
('Collection bijoux berbères',           5000,  'ouvert',  '2025-02-20', 3),
('Maroquinerie artisanale de Sfax',      9500,  'ouvert',  '2025-03-15', 4),
('Paniers en alfa de Kasserine',         3500,  'finance', '2025-01-05', 5);

INSERT INTO enchere (id_projet, id_investisseur, montant, message, statut, date_enchere) VALUES
(1, 2, 9000,  'Je crois en ce projet de poterie. La tradition de Nabeul mérite d\'être préservée et valorisée à l\'international.', 'en_attente', '2025-03-05 10:30:00'),
(1, 3, 10500, 'Ce projet est une opportunité unique de valoriser l\'artisanat tunisien. Mon réseau peut aider à l\'export.', 'acceptee',   '2025-03-06 14:00:00'),
(2, 2, 13000, 'Le tissage traditionnel est un patrimoine précieux. J\'ai déjà investi dans des projets similaires avec succès.', 'en_attente', '2025-03-11 09:15:00'),
(3, 3, 6000,  'Les bijoux berbères ont un énorme potentiel sur le marché européen. Ce projet mérite un soutien fort.', 'refusee',    '2025-03-08 16:45:00');

-- ============================================================
--  حرفة Tunisie — Extensions du système
--  Tables additionnelles pour profils professionnels
-- ============================================================

-- ── Table : formations ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS formations (
    id_formation   BIGINT PRIMARY KEY AUTO_INCREMENT,
    titre          VARCHAR(200) NOT NULL,
    description    TEXT,
    duree          INT, -- en heures
    niveau         ENUM('debutant','intermediaire','avance') DEFAULT 'debutant',
    date_creation  DATE DEFAULT (CURRENT_DATE)
);

-- ── Table : profil_professionnel ─────────────────────────────
CREATE TABLE IF NOT EXISTS profil_professionnel (
    id_profil      BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_user        BIGINT UNIQUE,
    bio            TEXT,
    specialite     VARCHAR(200),
    experience     INT, -- années d'expérience
    portfolio      TEXT, -- URL ou description du portfolio
    ville          VARCHAR(100),
    date_creation  DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE CASCADE
);

-- ── Table : profil_competences ───────────────────────────────
CREATE TABLE IF NOT EXISTS profil_competences (
    id_competence  BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_profil      BIGINT,
    competence     VARCHAR(100) NOT NULL,
    niveau         INT DEFAULT 50, -- Niveau de compétence de 0 à 100
    FOREIGN KEY (id_profil) REFERENCES profil_professionnel(id_profil) ON DELETE CASCADE
);

-- ── Table : experiences ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS experiences (
    id_experience  BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_user        BIGINT,
    titre          VARCHAR(200),
    entreprise     VARCHAR(200),
    date_debut     DATE,
    date_fin       DATE,
    description    TEXT,
    FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE CASCADE
);

-- ── Table : portfolio ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS portfolio (
    id_portfolio   BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_user        BIGINT,
    titre          VARCHAR(200),
    description    TEXT,
    image_url      VARCHAR(500),
    date_creation  DATE,
    FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE CASCADE
);

-- ── Table : avis ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS avis (
    id_avis        BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_user        BIGINT, -- l'artisan noté
    id_auteur      BIGINT, -- celui qui donne l'avis
    note           INT, -- Note de 1 à 5
    commentaire    TEXT,
    date_creation  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE CASCADE,
    FOREIGN KEY (id_auteur) REFERENCES user(id_user) ON DELETE CASCADE
);

-- ── Table : mentorat ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS mentorat (
    id_mentorat    BIGINT AUTO_INCREMENT PRIMARY KEY,
    mentor_id      BIGINT,
    apprenant_id   BIGINT,
    date_debut     DATE,
    status         ENUM('en_cours', 'termine'),
    FOREIGN KEY (mentor_id) REFERENCES user(id_user),
    FOREIGN KEY (apprenant_id) REFERENCES user(id_user)
);

-- ── Table de liaison : profil_formations ─────────────────────
CREATE TABLE IF NOT EXISTS profil_formations (
    id_profil      BIGINT,
    id_formation   BIGINT,
    date_inscription DATE,
    date_completion DATE,
    status         ENUM('en_cours', 'termine', 'abandonne') DEFAULT 'en_cours',
    PRIMARY KEY (id_profil, id_formation),
    FOREIGN KEY (id_profil) REFERENCES profil_professionnel(id_profil) ON DELETE CASCADE,
    FOREIGN KEY (id_formation) REFERENCES formations(id_formation) ON DELETE CASCADE
);

-- ── Données de démonstration pour les nouvelles tables ───────

-- Formations disponibles
INSERT INTO formations (titre, description, duree, niveau) VALUES
('Initiation à la poterie', 'Apprendre les bases de la poterie traditionnelle tunisienne', 40, 'debutant'),
('Tissage avancé', 'Maîtrise des techniques de tissage complexes', 80, 'avance'),
('Bijouterie berbère', 'Création de bijoux traditionnels', 60, 'intermediaire'),
('Maroquinerie moderne', 'Fusion de techniques traditionnelles et contemporaines', 70, 'intermediaire');

-- Profils professionnels
INSERT INTO profil_professionnel (id_user, bio, specialite, experience, portfolio, ville) VALUES
(4, 'Artisan potier passionné depuis 15 ans, spécialisé dans la céramique de Nabeul. J\'ai participé à plusieurs expositions internationales.', 'Poterie traditionnelle', 15, 'portfolio-karim.html', 'Nabeul');

-- Compétences
INSERT INTO profil_competences (id_profil, competence, niveau) VALUES
(1, 'Modelage à la main', 90),
(1, 'Cuisson au four', 85),
(1, 'Décoration traditionnelle', 95);

-- Expériences professionnelles
INSERT INTO experiences (id_user, titre, entreprise, date_debut, date_fin, description) VALUES
(4, 'Maître potier', 'Atelier familial Mansouri', '2010-01-01', NULL, 'Direction de l\'atelier familial, formation des apprentis, participation aux foires artisanales');

-- Portfolio
INSERT INTO portfolio (id_user, titre, description, image_url, date_creation) VALUES
(4, 'Collection Ramadan 2024', 'Assortiment de plats décoratifs pour le Ramadan', 'images/portfolio/ramadan-2024.jpg', '2024-03-01'),
(4, 'Vases contemporains', 'Fusion de tradition et modernité', 'images/portfolio/vases-modernes.jpg', '2024-01-15');

-- Avis
INSERT INTO avis (id_user, id_auteur, note, commentaire) VALUES
(4, 2, 5, 'Excellent travail ! Les pièces sont magnifiques et d\'une qualité exceptionnelle.'),
(4, 3, 4, 'Très bon artisan, livraison dans les délais. Je recommande.');

-- Mentorat
INSERT INTO mentorat (mentor_id, apprenant_id, date_debut, status) VALUES
(4, 1, '2024-06-01', 'en_cours');

-- Inscriptions aux formations
INSERT INTO profil_formations (id_profil, id_formation, date_inscription, status) VALUES
(1, 1, '2024-01-15', 'termine'),
(1, 2, '2024-03-01', 'en_cours');
