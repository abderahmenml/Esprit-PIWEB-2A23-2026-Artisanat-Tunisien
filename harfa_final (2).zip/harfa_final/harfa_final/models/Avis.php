<?php
/**
 * =========================================================================
 *  Harfa Tunisie - Model AVIS (BackOffice)
 *  Gestion admin des avis sur les encheres
 * =========================================================================
 */

class Avis
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /**
     * Récupère tous les avis avec détails enchère/projet/auteur
     */
    public function getAllAvisEncheres(int $limit = 1500): array
    {
        try {
            $sql = "SELECT a.id_avis_enchere, a.id_enchere, a.id_user, a.commentaire, a.note, a.created_at,
                           e.montant AS enchere_montant,
                           p.titre AS projet_titre,
                           u.nom, u.prenom, u.email
                    FROM avis_enchere a
                    JOIN enchere e ON e.id = a.id_enchere
                    JOIN projet p ON p.id = e.id_projet
                    JOIN user u ON u.id_user = a.id_user
                    ORDER BY a.created_at DESC
                    LIMIT :limit";

            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Erreur Avis::getAllAvisEncheres : ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Liste des encheres pour filtre (id + titre projet)
     */
    public function getEnchereOptionsForAvis(): array
    {
        try {
            $stmt = $this->pdo->prepare(
                "SELECT e.id, e.montant, e.date_enchere, p.titre AS projet_titre
                 FROM enchere e
                 JOIN projet p ON p.id = e.id_projet
                 ORDER BY e.date_enchere DESC"
            );
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Erreur Avis::getEnchereOptionsForAvis : ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Suppression admin d'un avis
     */
    public function deleteAvisByAdmin(int $idAvis): bool
    {
        try {
            $stmt = $this->pdo->prepare('DELETE FROM avis_enchere WHERE id_avis_enchere = :id');
            $stmt->execute([':id' => $idAvis]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log('Erreur Avis::deleteAvisByAdmin : ' . $e->getMessage());
            return false;
        }
    }
}
