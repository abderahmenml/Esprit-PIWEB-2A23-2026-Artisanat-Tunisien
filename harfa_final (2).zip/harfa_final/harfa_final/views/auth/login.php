<?php
// views/auth/login.php
// Variables : $errors (array), $old (array)
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion — حرفة Tunisie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --harfa-primary:#8B4513; --harfa-gold:#C9933A; }
        body {
            min-height:100vh;
            background: linear-gradient(135deg, #3d1a08 0%, #8B4513 50%, #C9933A 100%);
            display:flex; align-items:center; justify-content:center;
            font-family:'Segoe UI',sans-serif;
        }
        .login-card {
            width:100%; max-width:440px;
            border:none; border-radius:20px;
            box-shadow:0 20px 60px rgba(0,0,0,.35);
            overflow:hidden;
        }
        .login-header {
            background:linear-gradient(135deg,var(--harfa-primary),var(--harfa-gold));
            padding:2rem; text-align:center; color:#fff;
        }
        .login-header .brand { font-size:2.2rem; font-weight:800; letter-spacing:.02em; }
        .login-header .brand span { color:#ffe0a0; }
        .login-header .tagline { font-size:.85rem; opacity:.8; margin-top:.3rem; }
        .login-body { background:#fff; padding:2rem; }
        .form-control:focus { border-color:var(--harfa-gold); box-shadow:0 0 0 .2rem rgba(201,147,58,.25); }
        .btn-login { background:var(--harfa-primary); color:#fff; font-weight:700; border-radius:10px; padding:.75rem; }
        .btn-login:hover { background:var(--harfa-gold); color:#fff; }
        .demo-box { background:#fff8f0; border:1px solid #f0d9b5; border-radius:10px; padding:1rem; font-size:.82rem; }
        .demo-box code { background:#f0d9b5; border-radius:4px; padding:1px 5px; color:var(--harfa-primary); }
        .error-text { color:#dc3545; font-size:.8rem; margin-top:.3rem; }
    </style>
</head>
<body>
<div class="login-card">
    <div class="login-header">
        <div class="brand">حرفة <span>Tunisie</span></div>
        <div class="tagline">L'artisanat tunisien à l'ère du numérique</div>
    </div>
    <div class="login-body">
        <h5 class="fw-bold mb-4 text-center" style="color:var(--harfa-primary)">
            <i class="fa fa-lock me-2"></i>Connexion
        </h5>

        <?php if (!empty($errors['global'])): ?>
            <div class="alert alert-danger">
                <i class="fa fa-circle-exclamation me-2"></i>
                <?= htmlspecialchars($errors['global']) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="?module=auth&action=login" id="loginForm" novalidate>

            <!-- Email -->
            <div class="mb-3">
                <label for="email" class="form-label fw-semibold small">Adresse email</label>
                <div class="input-group">
                    <span class="input-group-text bg-white"><i class="fa fa-envelope text-muted"></i></span>
                    <input type="text"
                           id="email" name="email"
                           class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>"
                           value="<?= htmlspecialchars($old['email'] ?? '') ?>"
                           placeholder="votre@email.com">
                </div>
                <?php if (!empty($errors['email'])): ?>
                    <div class="error-text"><i class="fa fa-circle-xmark me-1"></i><?= htmlspecialchars($errors['email']) ?></div>
                <?php endif; ?>
                <div id="email-err" class="error-text" style="display:none"></div>
            </div>

            <!-- Mot de passe -->
            <div class="mb-4">
                <label for="password" class="form-label fw-semibold small">Mot de passe</label>
                <div class="input-group">
                    <span class="input-group-text bg-white"><i class="fa fa-key text-muted"></i></span>
                    <input type="password"
                           id="password" name="password"
                           class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>"
                           placeholder="••••••••">
                    <button type="button" class="input-group-text bg-white border-start-0"
                            onclick="togglePassword()">
                        <i class="fa fa-eye text-muted" id="eyeIcon"></i>
                    </button>
                </div>
                <?php if (!empty($errors['password'])): ?>
                    <div class="error-text"><i class="fa fa-circle-xmark me-1"></i><?= htmlspecialchars($errors['password']) ?></div>
                <?php endif; ?>
                <div id="pass-err" class="error-text" style="display:none"></div>
            </div>

            <button type="submit" class="btn btn-login w-100 mb-3">
                <i class="fa fa-right-to-bracket me-2"></i>Se connecter
            </button>
        </form>

        <!-- Comptes de démo -->
        <div class="demo-box">
            <div class="fw-semibold mb-2" style="color:var(--harfa-primary)">
                <i class="fa fa-circle-info me-1"></i>Comptes de démonstration
            </div>
            <div class="mb-1">
                <strong>Admin :</strong>
                <code>admin@harfa.tn</code> / <code>password</code>
            </div>
            <div class="mb-1">
                <strong>Investisseur :</strong>
                <code>sami@harfa.tn</code> / <code>password</code>
            </div>
            <div>
                <strong>Investisseur 2 :</strong>
                <code>nadia@harfa.tn</code> / <code>password</code>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePassword() {
    const p = document.getElementById('password');
    const i = document.getElementById('eyeIcon');
    if (p.type === 'password') { p.type = 'text'; i.classList.replace('fa-eye','fa-eye-slash'); }
    else                       { p.type = 'password'; i.classList.replace('fa-eye-slash','fa-eye'); }
}

// Validation JS temps réel
document.getElementById('email').addEventListener('blur', function() {
    const el  = this;
    const err = document.getElementById('email-err');
    if (!el.value.trim()) {
        err.textContent = 'L\'email est obligatoire.'; err.style.display = 'block';
        el.classList.add('is-invalid');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(el.value)) {
        err.textContent = 'Format d\'email invalide.'; err.style.display = 'block';
        el.classList.add('is-invalid');
    } else {
        err.style.display = 'none'; el.classList.remove('is-invalid'); el.classList.add('is-valid');
    }
});

document.getElementById('password').addEventListener('blur', function() {
    const el  = this;
    const err = document.getElementById('pass-err');
    if (!el.value.trim()) {
        err.textContent = 'Le mot de passe est obligatoire.'; err.style.display = 'block';
        el.classList.add('is-invalid');
    } else {
        err.style.display = 'none'; el.classList.remove('is-invalid'); el.classList.add('is-valid');
    }
});

document.getElementById('loginForm').addEventListener('submit', function(e) {
    let ok = true;
    const email = document.getElementById('email');
    const pass  = document.getElementById('password');
    if (!email.value.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
        email.classList.add('is-invalid'); ok = false;
    }
    if (!pass.value.trim()) {
        pass.classList.add('is-invalid'); ok = false;
    }
    if (!ok) e.preventDefault();
});
</script>
</body>
</html>
