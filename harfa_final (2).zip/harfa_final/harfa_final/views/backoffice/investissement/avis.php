<?php
// views/backoffice/investissement/avis.php
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Gestion des avis — Admin حرفة</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --p:#8B4513; --g:#C9933A; }
        body { background:#f0f2f5; font-family:'Segoe UI',sans-serif; }

        .sidebar { width:240px; min-height:100vh; position:fixed; left:0; top:0; z-index:100;
                   background:linear-gradient(180deg,var(--p) 0%,#4a1f08 100%); }
        .sidebar-brand { padding:1.4rem 1.3rem; border-bottom:1px solid rgba(255,255,255,.12); }
        .sidebar-brand .name { color:#fff; font-size:1.3rem; font-weight:800; }
        .sidebar-brand .sub  { color:rgba(255,255,255,.5); font-size:.75rem; }
        .sidebar a { display:flex; align-items:center; gap:.7rem; padding:.65rem 1.3rem;
                     color:rgba(255,255,255,.75); text-decoration:none; font-size:.88rem;
                     transition:background .15s; }
        .sidebar a:hover, .sidebar a.active { background:rgba(255,255,255,.14); color:#fff; }
        .sidebar a i { width:18px; text-align:center; }
        .sidebar-label { color:rgba(255,255,255,.35); font-size:.68rem; text-transform:uppercase;
                         letter-spacing:.08em; padding:.8rem 1.3rem .3rem; }

        .main { margin-left:240px; padding:2rem 2.5rem; min-height:100vh; }
        .page-title { font-size:1.5rem; font-weight:800; color:#1a1a2e; }

        .table-card { border:none; border-radius:14px; box-shadow:0 2px 14px rgba(0,0,0,.07); overflow:hidden; }
        .table { margin-bottom:0; }
        .table thead th { background:var(--p); color:#fff; font-size:.78rem;
                          text-transform:uppercase; letter-spacing:.05em; padding:.9rem 1rem;
                          border:none; font-weight:600; }
        .table tbody tr { border-bottom:1px solid #f0f0f0; }
        .table tbody tr:hover { background:#fff8f0; }
        .table td { padding:.85rem 1rem; vertical-align:middle; border:none; }

        .filter-bar { background:#fff; border-radius:12px; padding:1rem 1.3rem;
                      box-shadow:0 1px 8px rgba(0,0,0,.06); }
        .filter-bar .form-control, .filter-bar .form-select { font-size:.84rem; border-radius:8px; }

        #statsAvisModal .modal-dialog {
            max-width: min(1000px, 95vw);
        }

        #statsAvisModal .modal-body {
            max-height: 78vh;
            overflow: auto;
        }

        .chart-wrap {
            position: relative;
            height: 45vh;
            min-height: 260px;
            max-height: 460px;
        }

        .chart-wrap canvas {
            width: 100% !important;
            height: 100% !important;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-brand">
        <div class="name">حرفة <span style="color:var(--g)">Admin</span></div>
        <div class="sub">Tableau de bord</div>
    </div>
    <div class="sidebar-label">Modules</div>
    <a href="?module=investissement&action=index">
        <i class="fa fa-gavel"></i>Enchères
    </a>
    <a href="?module=avis&action=index" class="active">
        <i class="fa fa-comments"></i>Gestion des avis
    </a>
    <a href="#"><i class="fa fa-folder"></i>Projets</a>
    <a href="#"><i class="fa fa-users"></i>Utilisateurs</a>
    <a href="#"><i class="fa fa-briefcase"></i>Offres d'emploi</a>
    <div class="sidebar-label">Compte</div>
    <a href="#">
        <i class="fa fa-user-circle"></i>
        <?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?>
    </a>
    <a href="?module=auth&action=logout">
        <i class="fa fa-right-from-bracket"></i>Déconnexion
    </a>
</div>

<div class="main">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <div class="page-title"><i class="fa fa-comments me-2" style="color:var(--g)"></i>Gestion des avis</div>
            <div class="text-muted small">Modération des commentaires liés aux enchères</div>
        </div>
        <div class="text-muted small bg-white px-3 py-2 rounded-pill shadow-sm">
            <i class="fa fa-clock me-1"></i><?= date('d/m/Y H:i') ?>
        </div>
    </div>

    <?php if (!empty($flash)): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mb-4">
            <i class="fa fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'circle-exclamation' ?> me-2"></i>
            <?= htmlspecialchars($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#statsAvisModal">
            <i class="fa fa-chart-pie me-1"></i>Stats
        </button>
    </div>

    <form method="GET" action="" class="filter-bar mb-4">
        <input type="hidden" name="module" value="avis">
        <input type="hidden" name="action" value="index">

        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label mb-1 fw-semibold small">Liste des enchères</label>
                <select name="id_enchere" class="form-select">
                    <option value="0">Toutes les enchères</option>
                    <?php foreach ($enchere_options as $opt): ?>
                        <option value="<?= (int)$opt['id'] ?>" <?= ((int)($filters['id_enchere'] ?? 0) === (int)$opt['id']) ? 'selected' : '' ?>>
                            #<?= (int)$opt['id'] ?> - <?= htmlspecialchars($opt['projet_titre']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label mb-1 fw-semibold small">Note</label>
                <select name="note" class="form-select">
                    <option value="0">Toutes</option>
                    <option value="5" <?= ((int)($filters['note'] ?? 0) === 5) ? 'selected' : '' ?>>5 étoiles</option>
                    <option value="4" <?= ((int)($filters['note'] ?? 0) === 4) ? 'selected' : '' ?>>4 étoiles</option>
                    <option value="3" <?= ((int)($filters['note'] ?? 0) === 3) ? 'selected' : '' ?>>3 étoiles</option>
                    <option value="2" <?= ((int)($filters['note'] ?? 0) === 2) ? 'selected' : '' ?>>2 étoiles</option>
                    <option value="1" <?= ((int)($filters['note'] ?? 0) === 1) ? 'selected' : '' ?>>1 étoile</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label mb-1 fw-semibold small">Date début</label>
                <input type="date" name="date_debut" class="form-control" value="<?= htmlspecialchars($filters['date_debut'] ?? '') ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label mb-1 fw-semibold small">Date fin</label>
                <input type="date" name="date_fin" class="form-control" value="<?= htmlspecialchars($filters['date_fin'] ?? '') ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label mb-1 fw-semibold small">Recherche avancée</label>
                <input type="text" name="q" class="form-control" placeholder="auteur, projet, commentaire"
                       value="<?= htmlspecialchars($filters['q'] ?? '') ?>">
            </div>
        </div>

        <div class="d-flex gap-2 mt-3 justify-content-end">
            <button type="submit" class="btn" style="background:var(--p);color:#fff;">
                <i class="fa fa-filter me-1"></i>Filtrer
            </button>
            <a href="?module=avis&action=index" class="btn btn-outline-secondary">
                <i class="fa fa-rotate-left"></i>
            </a>
        </div>
    </form>

    <div class="card table-card">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#Avis</th>
                        <th>Enchère</th>
                        <th>Auteur</th>
                        <th>Projet</th>
                        <th>Note</th>
                        <th>Commentaire</th>
                        <th>Date</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($avis_encheres)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-5">
                            <i class="fa fa-comments fa-2x mb-2 d-block"></i>
                            Aucun commentaire forum trouvé
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($avis_encheres as $a): ?>
                    <tr>
                        <td class="text-muted small fw-semibold">#<?= (int)$a['id_avis_enchere'] ?></td>
                        <td>
                            <div class="fw-semibold" style="font-size:.9rem">#<?= (int)$a['id_enchere'] ?></div>
                            <div class="text-muted" style="font-size:.78rem">
                                <?= number_format((float)$a['enchere_montant'], 0, ',', ' ') ?> TND
                            </div>
                        </td>
                        <td>
                            <div class="fw-semibold" style="font-size:.9rem">
                                <?= htmlspecialchars($a['prenom'] . ' ' . $a['nom']) ?>
                            </div>
                            <div class="text-muted" style="font-size:.78rem">
                                <?= htmlspecialchars($a['email']) ?>
                            </div>
                        </td>
                        <td>
                            <div class="fw-semibold" style="font-size:.9rem">
                                <?= htmlspecialchars($a['projet_titre']) ?>
                            </div>
                        </td>
                        <td>
                            <span class="badge" style="background:#fff3cd;color:#856404;">
                                <i class="fa fa-star me-1"></i><?= (int)$a['note'] ?>/5
                            </span>
                        </td>
                        <td style="max-width:360px;">
                            <div style="font-size:.9rem; white-space:normal;">
                                <?= htmlspecialchars($a['commentaire']) ?>
                            </div>
                        </td>
                        <td class="text-muted small">
                            <?= date('d/m/Y', strtotime($a['created_at'])) ?><br>
                            <span class="text-muted"><?= date('H:i', strtotime($a['created_at'])) ?></span>
                        </td>
                        <td class="text-center">
                                <form method="POST" action="?module=avis&action=delete"
                                  onsubmit="return confirm('Supprimer cet avis ?')">
                                <input type="hidden" name="id_avis_enchere" value="<?= (int)$a['id_avis_enchere'] ?>">
                                <button class="btn btn-danger btn-sm" title="Supprimer">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="bg-white text-muted small px-3 py-2 border-top">
            <i class="fa fa-comments me-1"></i><?= count($avis_encheres ?? []) ?> commentaire(s) affiché(s)
        </div>
    </div>
</div>

<div class="modal fade" id="statsAvisModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-chart-pie me-2"></i>Statistiques des avis</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <div class="p-3 border rounded bg-light">
                            <div class="text-muted small">Total avis (filtre courant)</div>
                            <div class="fw-bold fs-4" style="color:var(--p)"><?= (int)($stats_avis['total'] ?? 0) ?></div>
                        </div>
                    </div>
                    <div class="col-md-8 text-muted small d-flex align-items-center">
                        Répartition des notes 1 à 5 étoiles.
                    </div>
                </div>
                <div class="chart-wrap">
                    <canvas id="avisPieChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(() => {
    const ctx = document.getElementById('avisPieChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['1 étoile', '2 étoiles', '3 étoiles', '4 étoiles', '5 étoiles'],
            datasets: [{
                data: [
                    <?= (int)($stats_avis['note_1'] ?? 0) ?>,
                    <?= (int)($stats_avis['note_2'] ?? 0) ?>,
                    <?= (int)($stats_avis['note_3'] ?? 0) ?>,
                    <?= (int)($stats_avis['note_4'] ?? 0) ?>,
                    <?= (int)($stats_avis['note_5'] ?? 0) ?>
                ],
                backgroundColor: ['#d9534f', '#f0ad4e', '#ffd966', '#8fd19e', '#198754'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
})();
</script>
</body>
</html>
