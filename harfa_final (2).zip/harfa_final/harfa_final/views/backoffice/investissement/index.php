<?php
// views/backoffice/investissement/index.php
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard Enchères — Admin حرفة</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --p:#8B4513; --g:#C9933A; }
        body { background:#f0f2f5; font-family:'Segoe UI',sans-serif; }

        /* Sidebar */
        .sidebar { width:240px; min-height:100vh; position:fixed; left:0; top:0; z-index:100;
                   background:linear-gradient(180deg,var(--p) 0%,#4a1f08 100%); }
        .sidebar-brand { padding:1.4rem 1.3rem; border-bottom:1px solid rgba(255,255,255,.12); }
        .sidebar-brand .name { color:#fff; font-size:1.3rem; font-weight:800; }
        .sidebar-brand .sub  { color:rgba(255,255,255,.5); font-size:.75rem; }
        .sidebar a { display:flex; align-items:center; gap:.7rem; padding:.65rem 1.3rem;
                     color:rgba(255,255,255,.75); text-decoration:none; font-size:.88rem;
                     transition:background .15s; }
        .sidebar a:hover, .sidebar a.active { background:rgba(255,255,255,.14); color:#fff; }
        .sidebar a i { width:18px; text-align:center; }
        .sidebar-label { color:rgba(255,255,255,.35); font-size:.68rem; text-transform:uppercase;
                         letter-spacing:.08em; padding:.8rem 1.3rem .3rem; }

        /* Main */
        .main { margin-left:240px; padding:2rem 2.5rem; min-height:100vh; }
        .page-title { font-size:1.5rem; font-weight:800; color:#1a1a2e; }

        /* KPI */
        .kpi-card { border:none; border-radius:14px; box-shadow:0 2px 14px rgba(0,0,0,.07);
                    background:#fff; padding:1.4rem 1.6rem; }
        .kpi-icon { width:52px; height:52px; border-radius:14px;
                    display:flex; align-items:center; justify-content:center; font-size:1.4rem; }
        .kpi-val { font-size:2rem; font-weight:800; line-height:1; }

        /* Table */
        .table-card { border:none; border-radius:14px; box-shadow:0 2px 14px rgba(0,0,0,.07); overflow:hidden; }
        .table { margin-bottom:0; }
        .table thead th { background:var(--p); color:#fff; font-size:.78rem;
                          text-transform:uppercase; letter-spacing:.05em; padding:.9rem 1rem;
                          border:none; font-weight:600; }
        .table tbody tr { border-bottom:1px solid #f0f0f0; }
        .table tbody tr:hover { background:#fff8f0; }
        .table td { padding:.85rem 1rem; vertical-align:middle; border:none; }

        /* Badges */
        .b-attente { background:#fff3cd; color:#856404; border-radius:20px; padding:.3em .9em; font-size:.76rem; font-weight:600; }
        .b-acceptee { background:#d1e7dd; color:#0f5132; border-radius:20px; padding:.3em .9em; font-size:.76rem; font-weight:600; }
        .b-refusee  { background:#f8d7da; color:#842029; border-radius:20px; padding:.3em .9em; font-size:.76rem; font-weight:600; }

        /* Filter */
        .filter-bar { background:#fff; border-radius:12px; padding:1rem 1.3rem;
                      box-shadow:0 1px 8px rgba(0,0,0,.06); }
        .filter-bar .form-control, .filter-bar .form-select { font-size:.84rem; border-radius:8px; }
    </style>
</head>
<body>

<!-- ── Sidebar ──────────────────── -->
<div class="sidebar">
    <div class="sidebar-brand">
        <div class="name">حرفة <span style="color:var(--g)">Admin</span></div>
        <div class="sub">Tableau de bord</div>
    </div>
    <div class="sidebar-label">Modules</div>
    <a href="?module=investissement&action=index" class="active">
        <i class="fa fa-gavel"></i>Enchères
    </a>
    <a href="?module=avis&action=index">
        <i class="fa fa-comments"></i>Gestion des avis
    </a>
    <a href="#"><i class="fa fa-folder"></i>Projets</a>
    <a href="#"><i class="fa fa-users"></i>Utilisateurs</a>
    <a href="#"><i class="fa fa-briefcase"></i>Offres d'emploi</a>
    <div class="sidebar-label">Compte</div>
    <a href="#">
        <i class="fa fa-user-circle"></i>
        <?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?>
    </a>
    <a href="?module=auth&action=logout">
        <i class="fa fa-right-from-bracket"></i>Déconnexion
    </a>
</div>

<!-- ── Main ────────────────────── -->
<div class="main">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <div class="page-title"><i class="fa fa-gavel me-2" style="color:var(--g)"></i>Gestion des enchères</div>
            <div class="text-muted small">Supervision du système d'investissement — حرفة Tunisie</div>
        </div>
        <div class="text-muted small bg-white px-3 py-2 rounded-pill shadow-sm">
            <i class="fa fa-clock me-1"></i><?= date('d/m/Y H:i') ?>
        </div>
    </div>

    <!-- Flash -->
    <?php if (!empty($flash)): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mb-4">
            <i class="fa fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'circle-exclamation' ?> me-2"></i>
            <?= htmlspecialchars($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- KPI -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="kpi-card d-flex align-items-center gap-3">
                <div class="kpi-icon" style="background:#fff3e0">
                    <i class="fa fa-gavel" style="color:var(--p)"></i>
                </div>
                <div>
                    <div class="kpi-val" style="color:var(--p)"><?= $stats['total'] ?></div>
                    <div class="text-muted small">Enchères totales</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="kpi-card d-flex align-items-center gap-3">
                <div class="kpi-icon" style="background:#e8f5e9">
                    <i class="fa fa-coins" style="color:#198754"></i>
                </div>
                <div>
                    <div class="kpi-val text-success"><?= number_format($stats['montant'], 0, ',', ' ') ?></div>
                    <div class="text-muted small">TND levés (acceptés)</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="kpi-card d-flex align-items-center gap-3">
                <div class="kpi-icon" style="background:#fff8e1">
                    <i class="fa fa-trophy" style="color:var(--g)"></i>
                </div>
                <div>
                    <div class="kpi-val" style="color:var(--g)"><?= $stats['finances'] ?></div>
                    <div class="text-muted small">Projets financés</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtres -->
    <form method="GET" action="" class="filter-bar mb-4">
        <input type="hidden" name="module" value="investissement">
        <input type="hidden" name="action" value="index">
        <div class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label mb-1 fw-semibold small">ID Projet</label>
                <input type="number" name="projet" class="form-control"
                       value="<?= htmlspecialchars($_GET['projet'] ?? '') ?>" placeholder="Ex: 1">
            </div>
            <div class="col-md-3">
                <label class="form-label mb-1 fw-semibold small">Statut</label>
                <select name="statut" class="form-select">
                    <option value="">Tous</option>
                    <option value="en_attente" <?= ($_GET['statut'] ?? '') === 'en_attente' ? 'selected' : '' ?>>En attente</option>
                    <option value="acceptee"   <?= ($_GET['statut'] ?? '') === 'acceptee'   ? 'selected' : '' ?>>Acceptée</option>
                    <option value="refusee"    <?= ($_GET['statut'] ?? '') === 'refusee'    ? 'selected' : '' ?>>Refusée</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label mb-1 fw-semibold small">Date</label>
                <input type="date" name="date" class="form-control" value="<?= htmlspecialchars($_GET['date'] ?? '') ?>">
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn w-100 fw-semibold" style="background:var(--p);color:#fff;border-radius:8px">
                    <i class="fa fa-filter me-1"></i>Filtrer
                </button>
                <a href="?module=investissement&action=index" class="btn btn-outline-secondary" style="border-radius:8px">
                    <i class="fa fa-rotate-left"></i>
                </a>
            </div>
        </div>
    </form>

    <!-- Tableau -->
    <div class="card table-card">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Investisseur</th>
                        <th>Projet</th>
                        <th>Montant</th>
                        <th>Statut</th>
                        <th>Date</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($encheres)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-5">
                            <i class="fa fa-inbox fa-2x mb-2 d-block"></i>
                            Aucune enchère trouvée
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($encheres as $e): ?>
                    <tr>
                        <td class="text-muted small fw-semibold">#<?= $e['id'] ?></td>

                        <td>
                            <div class="fw-semibold" style="font-size:.9rem">
                                <?= htmlspecialchars($e['inv_nom'] . ' ' . $e['inv_prenom']) ?>
                            </div>
                            <div class="text-muted" style="font-size:.78rem">
                                <?= htmlspecialchars($e['inv_email']) ?>
                            </div>
                        </td>

                        <td>
                            <div class="fw-semibold" style="font-size:.9rem">
                                <?= htmlspecialchars($e['projet_titre']) ?>
                            </div>
                            <div class="text-muted" style="font-size:.78rem">
                                Min: <?= number_format($e['projet_budget_min'], 0, ',', ' ') ?> TND
                            </div>
                        </td>

                        <td>
                            <span class="fw-bold" style="color:var(--p);font-size:1rem">
                                <?= number_format($e['montant'], 2, ',', ' ') ?>
                            </span>
                            <span class="text-muted small"> TND</span>
                        </td>

                        <td>
                            <span class="b-<?= $e['statut'] ?>">
                                <?= match($e['statut']) {
                                    'acceptee' => '✓ Acceptée',
                                    'refusee'  => '✗ Refusée',
                                    default    => '⏳ En attente'
                                } ?>
                            </span>
                        </td>

                        <td class="text-muted small">
                            <?= date('d/m/Y', strtotime($e['date_enchere'])) ?><br>
                            <span class="text-muted"><?= date('H:i', strtotime($e['date_enchere'])) ?></span>
                        </td>

                        <td>
                            <div class="d-flex gap-1 justify-content-center">
                                <?php if ($e['statut'] === 'en_attente'): ?>
                                <form method="POST" action="?module=investissement&action=accept"
                                      onsubmit="return confirm('Accepter cette enchère de <?= number_format($e['montant'],0,',','') ?> TND ?')">
                                    <input type="hidden" name="id" value="<?= $e['id'] ?>">
                                    <button class="btn btn-success btn-sm" title="Accepter" style="border-radius:7px">
                                        <i class="fa fa-check"></i>
                                    </button>
                                </form>
                                <form method="POST" action="?module=investissement&action=refuse"
                                      onsubmit="return confirm('Refuser cette enchère ?')">
                                    <input type="hidden" name="id" value="<?= $e['id'] ?>">
                                    <button class="btn btn-warning btn-sm" title="Refuser" style="border-radius:7px">
                                        <i class="fa fa-xmark"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                                <form method="POST" action="?module=investissement&action=delete"
                                      onsubmit="return confirm('Supprimer définitivement ?')">
                                    <input type="hidden" name="id" value="<?= $e['id'] ?>">
                                    <button class="btn btn-danger btn-sm" title="Supprimer" style="border-radius:7px">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="bg-white text-muted small px-3 py-2 border-top">
            <i class="fa fa-list me-1"></i><?= count($encheres) ?> résultat(s) affiché(s)
        </div>
    </div>

</div><!-- /main -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
