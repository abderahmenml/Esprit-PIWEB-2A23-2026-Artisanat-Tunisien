<?php
/**
 * =========================================================================
 *  حرفة Tunisie — FrontOffice - Liste des Projets à Financer
 * =========================================================================
 * Affiche tous les projets ouverts aux enchères avec :
 * - Titre et catégorie
 * - Budget minimum requis
 * - Meilleure offre actuelle
 * - Nombre d'enchères reçues
 * - Bouton "Enchérir"
 * 
 * Variables disponibles (passées depuis le contrôleur):
 *   $projets  : Array de projets ouverts
 *   $flash    : Messages de notification (success/error)
 */
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Investir — حرفة Tunisie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <style>
        /* ── VARIABLES DE COULEURS ────────────────────────────────────────── */
        :root { 
            --p:#8B4513;      /* Couleur primaire (marron) */
            --g:#C9933A;      /* Couleur secondaire (or) */
            --bg:#FDF6EC;     /* Couleur de fond */
        }
        
        body { 
            background:var(--bg); 
            font-family:'Segoe UI',sans-serif; 
        }

        /* ── NAVIGATION ────────────────────────────────────────────────────── */
        .navbar-harfa { 
            background:var(--p); 
            box-shadow: 0 2px 8px rgba(0,0,0,.1);
        }

        /* ── HERO SECTION ──────────────────────────────────────────────────── */
        .hero { 
            background:linear-gradient(135deg,var(--p),var(--g)); 
            color:#fff; 
            padding:3.5rem 0 2.5rem; 
        }

        /* ── CARTES DES PROJETS ────────────────────────────────────────────── */
        .card-projet { 
            border:none; 
            border-radius:14px; 
            box-shadow:0 4px 18px rgba(0,0,0,.08); 
            transition:transform .2s,box-shadow .2s; 
        }
        
        .card-projet:hover { 
            transform:translateY(-5px); 
            box-shadow:0 10px 30px rgba(0,0,0,.13); 
        }

        .top-bar { 
            height:5px; 
            background:linear-gradient(90deg,var(--p),var(--g)); 
        }

        .montant-min { 
            font-size:1.5rem; 
            font-weight:800; 
            color:var(--p); 
        }

        .badge-cat { 
            background:var(--g); 
            color:#fff; 
            font-size:.72rem; 
            border-radius:20px; 
            padding:.3em .8em; 
        }

        /* ── BARRE DE PROGRESSION ──────────────────────────────────────────── */
        .progress { 
            border-radius:4px; 
        }
        
        .progress-bar { 
            background:var(--g); 
        }

        /* ── BOUTON ENCHÉRIR ───────────────────────────────────────────────── */
        .btn-encherer { 
            background:var(--p); 
            color:#fff; 
            border-radius:8px; 
            font-weight:600; 
            transition: all .2s;
        }
        
        .btn-encherer:hover { 
            background:var(--g); 
            color:#fff; 
            transform: scale(1.02);
        }

        /* ── BOUTON ANALYSE IA ───────────────────────────────────────────────────────────── */
        .btn-analyse {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            padding: .55rem 1.3rem;
            display: inline-flex;
            align-items: center;
            gap: .5rem;
            transition: all .3s ease;
            box-shadow: 0 4px 15px rgba(26,26,46,.35);
            position: relative;
            overflow: hidden;
        }
        .btn-analyse::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, #8B4513, #C9933A);
            opacity: 0;
            transition: opacity .3s;
        }
        .btn-analyse:hover::before { opacity: 1; }
        .btn-analyse:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(139,69,19,.4);
            color: #fff;
        }
        .btn-analyse span, .btn-analyse i { position: relative; z-index: 1; }

        /* ── MODAL ANALYSE IA ──────────────────────────────────────────────────────────── */
        #modalAnalyseIA .modal-content {
            border: none;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 25px 80px rgba(0,0,0,.25);
        }
        #modalAnalyseIA .modal-header {
            background: linear-gradient(135deg, #1a1a2e, #8B4513);
            color: #fff;
            border: none;
            padding: 1.4rem 1.8rem;
        }
        #modalAnalyseIA .modal-header .modal-title {
            font-size: 1.15rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: .6rem;
        }
        #modalAnalyseIA .modal-body {
            padding: 1.8rem;
            background: #fafafa;
            max-height: 72vh;
            overflow-y: auto;
        }
        #modalAnalyseIA .modal-footer {
            background: #fff;
            border-top: 1px solid #f0e8dc;
            padding: 1rem 1.8rem;
            gap: .7rem;
        }

        /* Carte meilleur projet */
        .best-project-card {
            background: linear-gradient(135deg, #8B4513, #C9933A);
            color: #fff;
            border-radius: 14px;
            padding: 1.3rem 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            box-shadow: 0 6px 20px rgba(139,69,19,.3);
            animation: slideIn .5s ease;
        }
        .best-project-card .trophy-icon {
            font-size: 2.5rem;
            flex-shrink: 0;
        }
        .best-project-card .info .label {
            font-size: .75rem;
            opacity: .85;
            text-transform: uppercase;
            letter-spacing: .05em;
            font-weight: 600;
        }
        .best-project-card .info .titre {
            font-size: 1.2rem;
            font-weight: 800;
            line-height: 1.2;
        }
        .best-project-card .info .meta {
            font-size: .82rem;
            opacity: .9;
            margin-top: .3rem;
        }

        /* Texte analyse Markdown */
        #analyseContent { font-size: .92rem; line-height: 1.7; }
        #analyseContent h2 {
            font-size: 1.05rem;
            font-weight: 700;
            color: var(--p);
            border-left: 4px solid var(--g);
            padding-left: .7rem;
            margin: 1.5rem 0 .8rem;
        }
        #analyseContent h3 { font-size: .95rem; font-weight: 700; color: #333; margin: 1rem 0 .4rem; }
        #analyseContent ul { padding-left: 1.3rem; }
        #analyseContent li { margin-bottom: .3rem; }
        #analyseContent strong { color: var(--p); }

        /* Loading state */
        .analyse-loader {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 3rem 1rem;
            gap: 1.2rem;
        }
        .analyse-loader .spinner-ring {
            width: 60px; height: 60px;
            border: 5px solid #f0e8dc;
            border-top-color: var(--p);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        .analyse-loader .loader-text {
            color: #666;
            font-size: .95rem;
            text-align: center;
        }
        .analyse-loader .dots::after {
            content: '';
            animation: dots 1.5s steps(4, end) infinite;
        }

        /* Bouton PDF */
        .btn-pdf {
            background: linear-gradient(135deg, #c0392b, #e74c3c);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            padding: .5rem 1.2rem;
            display: inline-flex;
            align-items: center;
            gap: .5rem;
            transition: all .25s;
        }
        .btn-pdf:hover {
            background: linear-gradient(135deg, #a93226, #c0392b);
            color: #fff;
            transform: translateY(-1px);
        }

        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-12px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes dots {
            0%   { content: ''; }
            25%  { content: '.'; }
            50%  { content: '..'; }
            75%  { content: '...'; }
            100% { content: ''; }
        }

        /* ── ÉTAT VIDE (AUCUN PROJET) ──────────────────────────────────────── */
        .empty-state { 
            text-align:center; 
            padding:4rem 0; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-harfa navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="?module=investissement&action=liste">
            حرفة <span style="color:var(--g)">Tunisie</span>
        </a>
        <div class="ms-auto d-flex align-items-center gap-3">
            <a href="?module=investissement&action=forum" class="btn btn-outline-light btn-sm">
                <i class="fa fa-comments me-1"></i>Forum
            </a>
            <a href="?module=investissement&action=mes_encheres" class="btn btn-outline-light btn-sm">
                <i class="fa fa-list me-1"></i>Mes enchères
            </a>
            <span class="text-white-50 small">
                <i class="fa fa-user-circle me-1"></i>
                <?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?>
            </span>
            <a href="?module=auth&action=logout" class="btn btn-outline-light btn-sm">
                <i class="fa fa-right-from-bracket"></i>
            </a>
        </div>
    </div>
</nav>

<div class="hero text-center">
    <h1 class="fw-bold mb-2"><i class="fa fa-gavel me-2"></i>Investir dans l'artisanat tunisien</h1>
    <p class="opacity-75 mb-0">Soutenez des projets authentiques et participez à la préservation du patrimoine</p>
</div>

<div class="container py-5">

    <?php if (!empty($flash)): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mb-4">
            <?= htmlspecialchars($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold mb-0">
            Projets ouverts
            <span class="badge ms-2" style="background:var(--g)"><?= count($projets) ?></span>
        </h5>
        <?php if (!empty($projets)): ?>
        <button id="btnAnalyseIA" class="btn-analyse" onclick="lancerAnalyseIA()">
            <i class="fa fa-robot"></i>
            <span>Analyser les projets</span>
            <i class="fa fa-sparkles" style="font-size:.8rem;opacity:.8"></i>
        </button>
        <?php endif; ?>
    </div>

    <?php if (empty($projets)): ?>
        <div class="empty-state">
            <i class="fa fa-folder-open fa-4x text-muted mb-3"></i>
            <p class="text-muted fs-5">Aucun projet disponible pour le moment.</p>
        </div>
    <?php else: ?>

    <div class="row g-4">
        <?php foreach ($projets as $p):
            $highest   = (float)$p['meilleure_offre'];
            $bmin      = (float)$p['budget_min'];
            $pct       = $bmin > 0 ? min(100, round(($highest / $bmin) * 100)) : 0;
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="card card-projet h-100">
                <div class="top-bar"></div>
                <div class="card-body p-4 d-flex flex-column">

                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 class="card-title fw-bold mb-0" style="font-size:1rem">
                            <?= htmlspecialchars($p['titre']) ?>
                        </h5>
                        <?php if ($p['categorie_nom']): ?>
                            <span class="badge-cat ms-2 text-nowrap"><?= htmlspecialchars($p['categorie_nom']) ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <div class="text-muted small mb-1">Budget minimum requis</div>
                        <div class="montant-min"><?= number_format($bmin, 0, ',', ' ') ?> <span class="fs-6 fw-normal text-muted">TND</span></div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between small text-muted mb-1">
                            <span>Meilleure offre</span>
                            <span class="fw-semibold text-dark">
                                <?= $highest > 0 ? number_format($highest, 0, ',', ' ') . ' TND' : 'Aucune offre' ?>
                            </span>
                        </div>
                        <div class="progress" style="height:7px;border-radius:4px;">
                            <div class="progress-bar" role="progressbar" style="width:<?= $pct ?>%"></div>
                        </div>
                        <div class="text-end small text-muted mt-1"><?= $pct ?>% du budget atteint</div>
                    </div>

                    <div class="text-muted small mb-4">
                        <i class="fa fa-users me-1"></i><?= $p['nb_encheres'] ?> enchère(s) &nbsp;|&nbsp;
                        <i class="fa fa-calendar me-1"></i><?= date('d/m/Y', strtotime($p['date_creation'])) ?>
                    </div>

                    <div class="mt-auto">
                        <a href="?module=investissement&action=form&id_projet=<?= $p['id'] ?>"
                           class="btn btn-encherer w-100">
                            <i class="fa fa-gavel me-2"></i>Enchérir sur ce projet
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<!-- MODAL ANALYSE IA -->
<div class="modal fade" id="modalAnalyseIA" tabindex="-1" aria-labelledby="modalAnalyseTitre" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalAnalyseTitre">
          <i class="fa fa-robot"></i>
          Analyse IA des Projets &mdash; <span style="color:var(--g)">حرفة Tunisie</span>
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="analyseModalBody">
        <!-- Chargement par défaut -->
        <div class="analyse-loader" id="analyseLoader">
          <div class="spinner-ring"></div>
          <div class="loader-text">
            <strong>Gemini AI analyse vos projets</strong><br>
            <span class="text-muted">Veuillez patienter, cela peut prendre quelques secondes<span class="dots"></span></span>
          </div>
        </div>
        <!-- Contenu de l'analyse -->
        <div id="analyseResultat" style="display:none">
          <div id="bestProjectCard"></div>
          <div id="analyseContent"></div>
        </div>
        <!-- Erreur -->
        <div id="analyseErreur" style="display:none" class="alert alert-danger">
          <i class="fa fa-circle-exclamation me-2"></i>
          <span id="analyseErreurMsg"></span>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">
          <i class="fa fa-xmark me-1"></i>Fermer
        </button>
        <button type="button" id="btnTelechargerPDF" class="btn-pdf" style="display:none" onclick="telechargerPDF()">
          <i class="fa fa-file-pdf"></i>
          Télécharger le rapport PDF
        </button>
      </div>
    </div>
  </div>
</div>

<script>
// ═════════════════════════════════════════════════════════════════
// ANALYSE IA — Logic JS
// ═════════════════════════════════════════════════════════════════

let analyseData = null;

/**
 * Lance l'analyse IA et ouvre le modal
 */
async function lancerAnalyseIA() {
    // Ouvrir le modal
    const modal = new bootstrap.Modal(document.getElementById('modalAnalyseIA'));
    modal.show();

    // Réinitialiser l'état
    document.getElementById('analyseLoader').style.display = 'flex';
    document.getElementById('analyseResultat').style.display = 'none';
    document.getElementById('analyseErreur').style.display = 'none';
    document.getElementById('btnTelechargerPDF').style.display = 'none';
    analyseData = null;

    try {
        const formData = new FormData();
        formData.append('_csrf', '1'); // simple anti-CSRF token

        const response = await fetch('?module=investissement&action=analyse_ia', {
            method: 'POST',
            body: formData
        });

        const json = await response.json();

        if (json.error) {
            throw new Error(json.error);
        }

        analyseData = json;
        afficherAnalyse(json);

    } catch (err) {
        document.getElementById('analyseLoader').style.display = 'none';
        document.getElementById('analyseErreur').style.display = 'block';
        document.getElementById('analyseErreurMsg').textContent = err.message || 'Erreur inattendue. Veuillez réessayer.';
    }
}

/**
 * Affiche les résultats de l'analyse dans le modal
 */
function afficherAnalyse(data) {
    document.getElementById('analyseLoader').style.display = 'none';

    // Carte meilleur projet
    const mp = data.meilleur_projet;
    if (mp) {
        const pct = mp.budget_min > 0
            ? Math.min(100, Math.round((parseFloat(mp.meilleure_offre) / parseFloat(mp.budget_min)) * 100))
            : 0;
        const budgetFmt = parseFloat(mp.budget_min).toLocaleString('fr-TN') + ' TND';
        const meilleureFmt = parseFloat(mp.meilleure_offre).toLocaleString('fr-TN') + ' TND';

        document.getElementById('bestProjectCard').innerHTML = `
            <div class="best-project-card">
                <div class="trophy-icon">🏆</div>
                <div class="info">
                    <div class="label">Meilleur projet recommandé par Gemini AI</div>
                    <div class="titre">${escHtml(mp.titre)}</div>
                    <div class="meta">
                        <span class="me-3"><i class="fa fa-tag me-1"></i>${escHtml(mp.categorie_nom || 'N/A')}</span>
                        <span class="me-3"><i class="fa fa-coins me-1"></i>Budget min: ${budgetFmt}</span>
                        <span class="me-3"><i class="fa fa-trophy me-1"></i>Meilleure offre: ${meilleureFmt}</span>
                        <span><i class="fa fa-percent me-1"></i>Financement: ${pct}%</span>
                    </div>
                </div>
                <div class="ms-auto">
                    <a href="?module=investissement&action=form&id_projet=${mp.id}"
                       class="btn btn-light btn-sm fw-bold" style="color:var(--p)">
                        <i class="fa fa-gavel me-1"></i>Enchérir
                    </a>
                </div>
            </div>
        `;
    }

    // Contenu analyse (markdown → HTML)
    const analyseHtml = marked.parse(data.analyse || '');
    document.getElementById('analyseContent').innerHTML = analyseHtml;

    document.getElementById('analyseResultat').style.display = 'block';
    document.getElementById('btnTelechargerPDF').style.display = 'inline-flex';
}

/**
 * Escaping HTML
 */
function escHtml(str) {
    const d = document.createElement('div');
    d.textContent = str || '';
    return d.innerHTML;
}

/**
 * Télécharge le rapport d'analyse en PDF
 */
async function telechargerPDF() {
    const btn = document.getElementById('btnTelechargerPDF');
    const originalHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Génération...';
    btn.disabled = true;

    try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

        const pageW = doc.internal.pageSize.getWidth();
        const pageH = doc.internal.pageSize.getHeight();
        const margin = 15;
        const contentW = pageW - margin * 2;
        let y = margin;

        // ── En-tête
        doc.setFillColor(139, 69, 19);
        doc.rect(0, 0, pageW, 35, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        doc.text('Harfa Tunisie — Rapport d\'Analyse IA', margin, 16);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Généré par Gemini AI — ' + new Date().toLocaleDateString('fr-TN', { day:'2-digit', month:'long', year:'numeric' }), margin, 26);

        y = 45;
        doc.setTextColor(30, 30, 30);

        // ── Meilleur projet
        if (analyseData && analyseData.meilleur_projet) {
            const mp = analyseData.meilleur_projet;
            doc.setFillColor(201, 147, 58);
            doc.roundedRect(margin, y, contentW, 28, 3, 3, 'F');
            doc.setTextColor(255, 255, 255);
            doc.setFontSize(9);
            doc.setFont('helvetica', 'bold');
            doc.text('MEILLEUR PROJET RECOMMANDE', margin + 5, y + 8);
            doc.setFontSize(13);
            doc.text(mp.titre || 'N/A', margin + 5, y + 17);
            doc.setFontSize(9);
            doc.setFont('helvetica', 'normal');
            doc.text('Catégorie: ' + (mp.categorie_nom || 'N/A') + '   |   Budget min: ' +
                parseFloat(mp.budget_min).toLocaleString('fr-TN') + ' TND', margin + 5, y + 24);
            y += 36;
            doc.setTextColor(30, 30, 30);
        }

        // ── Texte analyse (plain text nettoyé)
        const rawText = (analyseData && analyseData.analyse) ? analyseData.analyse : '';
        // Remove markdown and emojis/special characters that break jsPDF
        const cleanText = rawText
            .replace(/#{1,6}\s?/g, '')
            .replace(/\*\*(.*?)\*\*/g, '$1')
            .replace(/\*(.*?)\*/g, '$1')
            .replace(/`/g, '')
            .replace(/[\u{1F300}-\u{1F9FF}]/gu, '') // symbols & pictographs
            .replace(/[\u{2600}-\u{26FF}]/gu, '') // miscellaneous symbols
            .replace(/[\u{2700}-\u{27BF}]/gu, ''); // dingbats

        const lines = cleanText.split('\n');

        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');

        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed) { y += 3; continue; }

            // Sections principales (detect by common keywords since emojis are removed)
            const isSection = trimmed.includes('Analyse des Projets') || 
                              trimmed.includes('Recommandation') || 
                              trimmed.includes('Conseils d\'Investissement') ||
                              trimmed.match(/^[A-Z][a-z]+(\s[A-Z][a-z]+)*$/); // Capitalized short phrases

            if (isSection && trimmed.length < 50) {
                if (y > pageH - 25) { doc.addPage(); y = margin; }
                doc.setFillColor(248, 240, 230);
                doc.rect(margin, y - 4, contentW, 9, 'F');
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(10);
                doc.setTextColor(139, 69, 19);
                const wrapped = doc.splitTextToSize(trimmed, contentW - 4);
                doc.text(wrapped, margin + 2, y + 2);
                y += wrapped.length * 6 + 4;
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(9);
                doc.setTextColor(30, 30, 30);
            } else {
                if (y > pageH - 20) { doc.addPage(); y = margin; }
                const wrapped = doc.splitTextToSize(trimmed, contentW);
                doc.text(wrapped, margin, y);
                y += wrapped.length * 5 + 2;
            }
        }

        // ── Pied de page
        const totalPages = doc.internal.getNumberOfPages();
        for (let i = 1; i <= totalPages; i++) {
            doc.setPage(i);
            doc.setFillColor(245, 240, 235);
            doc.rect(0, pageH - 12, pageW, 12, 'F');
            doc.setFontSize(7);
            doc.setTextColor(139, 69, 19);
            doc.setFont('helvetica', 'italic');
            doc.text('Harfa Tunisie — Rapport généré par Gemini AI', margin, pageH - 4);
            doc.setFont('helvetica', 'normal');
            doc.text('Page ' + i + ' / ' + totalPages, pageW - margin, pageH - 4, { align: 'right' });
        }

        const dateStr = new Date().toISOString().slice(0, 10);
        doc.save(`harfa_analyse_projets_${dateStr}.pdf`);

    } catch (err) {
        alert('Erreur lors de la génération du PDF: ' + err.message);
    } finally {
        btn.innerHTML = originalHtml;
        btn.disabled = false;
    }
}
</script>
</body>
</html>
