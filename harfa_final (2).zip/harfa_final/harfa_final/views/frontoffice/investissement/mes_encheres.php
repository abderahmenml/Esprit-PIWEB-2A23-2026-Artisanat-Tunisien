<?php
// views/frontoffice/investissement/mes_encheres.php
$user = $_SESSION['user'];

$nb_total    = count($encheres);
$nb_accepte  = count(array_filter($encheres, fn($e) => $e['statut'] === 'acceptee'));
$nb_attente  = count(array_filter($encheres, fn($e) => $e['statut'] === 'en_attente'));
$nb_refuse   = count(array_filter($encheres, fn($e) => $e['statut'] === 'refusee'));
$total_invest = array_sum(array_column(
    array_filter($encheres, fn($e) => $e['statut'] === 'acceptee'), 'montant'
));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Mes enchères — حرفة Tunisie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --p:#8B4513; --g:#C9933A; --bg:#FDF6EC; }
        body { background:var(--bg); font-family:'Segoe UI',sans-serif; }
        .navbar-harfa { background:var(--p); }
        .page-hero { background:linear-gradient(135deg,var(--p),var(--g)); color:#fff; padding:2.5rem 0 2rem; }
        .kpi { border:none; border-radius:12px; box-shadow:0 2px 12px rgba(0,0,0,.07); padding:1.2rem 1.5rem; background:#fff; }
        .kpi-val { font-size:2rem; font-weight:800; line-height:1; }
        .enchere-card { border:none; border-radius:12px; box-shadow:0 3px 14px rgba(0,0,0,.07); background:#fff; transition:transform .18s; }
        .enchere-card:hover { transform:translateY(-3px); }
        .status-badge { font-size:.78rem; border-radius:20px; padding:.35em .9em; font-weight:600; }
        .s-attente { background:#fff3cd; color:#856404; }
        .s-acceptee { background:#d1e7dd; color:#0f5132; }
        .s-refusee  { background:#f8d7da; color:#842029; }
        .montant-val { font-size:1.3rem; font-weight:800; color:var(--p); }
    </style>
</head>
<body>

<nav class="navbar navbar-dark navbar-harfa">
    <div class="container">
        <a class="navbar-brand fw-bold" href="?module=investissement&action=liste">
            حرفة <span style="color:var(--g)">Tunisie</span>
        </a>
        <div class="d-flex align-items-center gap-3">
            <a href="?module=investissement&action=forum" class="btn btn-outline-light btn-sm">
                <i class="fa fa-comments me-1"></i>Forum
            </a>
            <a href="?module=investissement&action=liste" class="btn btn-outline-light btn-sm">
                <i class="fa fa-search me-1"></i>Explorer
            </a>
            <span class="text-white-50 small"><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></span>
            <a href="?module=auth&action=logout" class="btn btn-outline-light btn-sm">
                <i class="fa fa-right-from-bracket"></i>
            </a>
        </div>
    </div>
</nav>

<div class="page-hero text-center">
    <h2 class="fw-bold mb-1"><i class="fa fa-list-check me-2"></i>Mes enchères</h2>
    <p class="opacity-75 mb-0">Tableau de bord de vos investissements</p>
</div>

<div class="container py-4">

    <?php if (!empty($flash)): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show">
            <?= htmlspecialchars($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- KPI -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="kpi text-center">
                <div class="kpi-val" style="color:var(--p)"><?= $nb_total ?></div>
                <div class="text-muted small mt-1">Total</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="kpi text-center">
                <div class="kpi-val text-success"><?= $nb_accepte ?></div>
                <div class="text-muted small mt-1">Acceptées</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="kpi text-center">
                <div class="kpi-val text-warning"><?= $nb_attente ?></div>
                <div class="text-muted small mt-1">En attente</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="kpi text-center">
                <div class="kpi-val" style="color:var(--g)"><?= number_format($total_invest, 0, ',', ' ') ?></div>
                <div class="text-muted small mt-1">TND investis</div>
            </div>
        </div>
    </div>

    <?php if (empty($encheres)): ?>
        <div class="text-center py-5">
            <i class="fa fa-gavel fa-4x text-muted mb-3"></i>
            <p class="text-muted fs-5">Vous n'avez soumis aucune enchère.</p>
            <a href="?module=investissement&action=liste" class="btn" style="background:var(--p);color:#fff">
                <i class="fa fa-search me-2"></i>Découvrir les projets
            </a>
        </div>
    <?php else: ?>

    <div class="row g-3">
        <?php foreach ($encheres as $e): ?>
        <div class="col-md-6 col-lg-4">
            <div class="enchere-card p-4 h-100 d-flex flex-column">

                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h6 class="fw-bold mb-0" style="font-size:.93rem">
                        <?= htmlspecialchars($e['projet_titre']) ?>
                    </h6>
                    <span class="status-badge ms-2
                        <?= $e['statut'] === 'acceptee' ? 's-acceptee' : ($e['statut'] === 'refusee' ? 's-refusee' : 's-attente') ?>">
                        <?= match($e['statut']) {
                            'acceptee' => '✓ Acceptée',
                            'refusee'  => '✗ Refusée',
                            default    => '⏳ En attente'
                        } ?>
                    </span>
                </div>

                <div class="montant-val mb-2"><?= number_format($e['montant'], 2, ',', ' ') ?> TND</div>

                <div class="small text-muted mb-3">
                    <i class="fa fa-calendar me-1"></i>
                    <?= date('d/m/Y à H:i', strtotime($e['date_enchere'])) ?>
                </div>

                <?php if ($e['message']): ?>
                <div class="bg-light rounded p-2 small text-muted fst-italic mt-auto">
                    "<?= htmlspecialchars(mb_substr($e['message'], 0, 90)) ?><?= mb_strlen($e['message']) > 90 ? '…' : '' ?>"
                </div>
                <?php endif; ?>

            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
