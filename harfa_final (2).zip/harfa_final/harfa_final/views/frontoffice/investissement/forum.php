<?php
/**
 * Forum des enchères: afficher toutes les enchères + ajout d'avis (note 1 à 5)
 */
$user = $_SESSION['user'];
$currentUserId = (int)($user['id_user'] ?? 0);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Forum des enchères — حرفة Tunisie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --p:#8B4513; --g:#C9933A; --bg:#FDF6EC; }
        body { background:var(--bg); font-family:'Segoe UI',sans-serif; }
        .navbar-harfa { background:var(--p); }
        .hero { background:linear-gradient(135deg,var(--p),var(--g)); color:#fff; padding:2.6rem 0 2rem; }
        .card-forum { border:none; border-radius:14px; box-shadow:0 4px 18px rgba(0,0,0,.08); }
        .rate-pill { background:#fff4dd; color:#7a4d0a; border-radius:999px; padding:.2rem .7rem; font-size:.82rem; font-weight:700; }
        .btn-add-avis { background:var(--p); color:#fff; border:none; }
        .btn-add-avis:hover { background:var(--g); color:#fff; }
        .avis-item { background:#fff; border:1px solid #eee; border-radius:10px; padding:.8rem .9rem; }
        .avis-actions .btn { border-radius:8px; }

        .star-rating {
            display:inline-flex;
            flex-direction:row-reverse;
            gap:.2rem;
        }
        .star-rating input { display:none; }
        .star-rating label {
            cursor:pointer;
            color:#d5d5d5;
            font-size:1.25rem;
            line-height:1;
        }
        .star-rating input:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label {
            color:#d7941c;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark navbar-harfa">
    <div class="container">
        <a class="navbar-brand fw-bold" href="?module=investissement&action=liste">
            حرفة <span style="color:var(--g)">Tunisie</span>
        </a>
        <div class="ms-auto d-flex align-items-center gap-2">
            <a href="?module=investissement&action=liste" class="btn btn-outline-light btn-sm">
                <i class="fa fa-compass me-1"></i>Projets
            </a>
            <a href="?module=investissement&action=mes_encheres" class="btn btn-outline-light btn-sm">
                <i class="fa fa-list me-1"></i>Mes enchères
            </a>
            <a href="?module=investissement&action=forum" class="btn btn-light btn-sm">
                <i class="fa fa-comments me-1"></i>Forum
            </a>
            <span class="text-white-50 small ms-1">
                <?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?>
            </span>
            <a href="?module=auth&action=logout" class="btn btn-outline-light btn-sm">
                <i class="fa fa-right-from-bracket"></i>
            </a>
        </div>
    </div>
</nav>

<div class="hero text-center">
    <h2 class="fw-bold mb-1"><i class="fa fa-comments me-2"></i>Forum des enchères</h2>
    <p class="mb-0 opacity-75">Tous les utilisateurs peuvent donner leur avis sur chaque enchère</p>
</div>

<div class="container py-4">
    <?php if (!empty($flash)): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mb-4">
            <?= htmlspecialchars($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (empty($encheres)): ?>
        <div class="text-center py-5">
            <i class="fa fa-gavel fa-3x text-muted mb-3"></i>
            <p class="text-muted mb-0">Aucune enchère disponible.</p>
        </div>
    <?php else: ?>

    <div class="row g-4">
        <?php foreach ($encheres as $e): ?>
            <?php
                $idEnchere = (int)$e['id'];
                $avisList = $avisByEnchere[$idEnchere] ?? [];
            ?>
            <div class="col-12">
                <div class="card card-forum">
                    <div class="card-body p-4">
                        <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
                            <div>
                                <h5 class="mb-1 fw-bold"><?= htmlspecialchars($e['projet_titre']) ?></h5>
                                <div class="text-muted small">
                                    Enchère par <?= htmlspecialchars($e['inv_prenom'] . ' ' . $e['inv_nom']) ?>
                                    • <?= date('d/m/Y H:i', strtotime($e['date_enchere'])) ?>
                                </div>
                            </div>
                            <div class="text-end">
                                <div class="fw-bold fs-5" style="color:var(--p)"><?= number_format((float)$e['montant'], 0, ',', ' ') ?> TND</div>
                                <span class="rate-pill"><i class="fa fa-star me-1"></i><?= number_format((float)$e['note_moyenne'], 1, ',', ' ') ?>/5</span>
                                <span class="badge text-bg-secondary ms-1"><?= (int)$e['nb_avis'] ?> avis</span>
                            </div>
                        </div>

                        <p class="mb-3"><?= nl2br(htmlspecialchars((string)$e['message'])) ?></p>

                        <button class="btn btn-add-avis btn-sm" data-bs-toggle="collapse" data-bs-target="#avisForm<?= $idEnchere ?>">
                            <i class="fa fa-pen me-1"></i>Ajouter un avis
                        </button>

                        <div class="collapse mt-3" id="avisForm<?= $idEnchere ?>">
                            <div class="card card-body" style="background:#fffaf2; border:1px solid #f1dfbd;">
                                <form method="POST" action="?module=investissement&action=add_avis">
                                    <input type="hidden" name="id_enchere" value="<?= $idEnchere ?>">

                                    <div class="mb-2 fw-semibold">Ecrire ton avis a propos ce enchere</div>

                                    <div class="mb-3">
                                        <textarea class="form-control" name="commentaire" rows="3" placeholder="Ton avis..."></textarea>
                                    </div>

                                    <div class="row g-2 align-items-end">
                                        <div class="col-md-4">
                                            <label class="form-label">Rate it (1 to 5)</label>
                                            <div class="star-rating">
                                                <input type="radio" id="add-star-<?= $idEnchere ?>-5" name="note" value="5" checked>
                                                <label for="add-star-<?= $idEnchere ?>-5" title="5 étoiles"><i class="fa fa-star"></i></label>
                                                <input type="radio" id="add-star-<?= $idEnchere ?>-4" name="note" value="4">
                                                <label for="add-star-<?= $idEnchere ?>-4" title="4 étoiles"><i class="fa fa-star"></i></label>
                                                <input type="radio" id="add-star-<?= $idEnchere ?>-3" name="note" value="3">
                                                <label for="add-star-<?= $idEnchere ?>-3" title="3 étoiles"><i class="fa fa-star"></i></label>
                                                <input type="radio" id="add-star-<?= $idEnchere ?>-2" name="note" value="2">
                                                <label for="add-star-<?= $idEnchere ?>-2" title="2 étoiles"><i class="fa fa-star"></i></label>
                                                <input type="radio" id="add-star-<?= $idEnchere ?>-1" name="note" value="1">
                                                <label for="add-star-<?= $idEnchere ?>-1" title="1 étoile"><i class="fa fa-star"></i></label>
                                            </div>
                                        </div>
                                        <div class="col-md-8 text-md-end">
                                            <button type="submit" class="btn btn-add-avis">
                                                <i class="fa fa-paper-plane me-1"></i>Envoyer l'avis
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <hr>
                        <h6 class="fw-bold mb-3">Avis sur cette enchère</h6>

                        <?php if (empty($avisList)): ?>
                            <p class="text-muted small mb-0">Aucun avis pour le moment.</p>
                        <?php else: ?>
                            <div class="d-grid gap-2">
                                <?php foreach ($avisList as $avis): ?>
                                    <?php
                                        $idAvis = (int)$avis['id_avis_enchere'];
                                        $isOwner = (int)$avis['id_user'] === $currentUserId;
                                    ?>
                                    <div class="avis-item">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <strong><?= htmlspecialchars($avis['prenom'] . ' ' . $avis['nom']) ?></strong>
                                            <span class="badge" style="background:#f3e2be;color:#6d470a;">
                                                <i class="fa fa-star me-1"></i><?= (int)$avis['note'] ?>/5
                                            </span>
                                        </div>
                                        <div class="small mb-1"><?= nl2br(htmlspecialchars((string)$avis['commentaire'])) ?></div>
                                        <div class="text-muted" style="font-size:.8rem;">
                                            <?= date('d/m/Y H:i', strtotime($avis['created_at'])) ?>
                                        </div>

                                        <?php if ($isOwner): ?>
                                            <div class="avis-actions mt-2 d-flex gap-2">
                                                <button class="btn btn-outline-secondary btn-sm" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#editAvis<?= $idAvis ?>">
                                                    <i class="fa fa-pen me-1"></i>Modifier
                                                </button>
                                                <form method="POST" action="?module=investissement&action=delete_avis"
                                                      onsubmit="return confirm('Supprimer cet avis ?')">
                                                    <input type="hidden" name="id_avis_enchere" value="<?= $idAvis ?>">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm">
                                                        <i class="fa fa-trash me-1"></i>Supprimer
                                                    </button>
                                                </form>
                                            </div>

                                            <div class="collapse mt-3" id="editAvis<?= $idAvis ?>">
                                                <div class="card card-body" style="background:#fffaf2; border:1px solid #f1dfbd;">
                                                    <form method="POST" action="?module=investissement&action=update_avis">
                                                        <input type="hidden" name="id_avis_enchere" value="<?= $idAvis ?>">
                                                        <div class="mb-2 fw-semibold">Modifier ton avis</div>

                                                        <div class="mb-3">
                                                            <textarea class="form-control" name="commentaire" rows="3"><?= htmlspecialchars((string)$avis['commentaire']) ?></textarea>
                                                        </div>

                                                        <div class="row g-2 align-items-end">
                                                            <div class="col-md-4">
                                                                <label class="form-label">Rate it (1 to 5)</label>
                                                                <div class="star-rating">
                                                                    <input type="radio" id="edit-star-<?= $idAvis ?>-5" name="note" value="5" <?= (int)$avis['note'] === 5 ? 'checked' : '' ?>>
                                                                    <label for="edit-star-<?= $idAvis ?>-5" title="5 étoiles"><i class="fa fa-star"></i></label>
                                                                    <input type="radio" id="edit-star-<?= $idAvis ?>-4" name="note" value="4" <?= (int)$avis['note'] === 4 ? 'checked' : '' ?>>
                                                                    <label for="edit-star-<?= $idAvis ?>-4" title="4 étoiles"><i class="fa fa-star"></i></label>
                                                                    <input type="radio" id="edit-star-<?= $idAvis ?>-3" name="note" value="3" <?= (int)$avis['note'] === 3 ? 'checked' : '' ?>>
                                                                    <label for="edit-star-<?= $idAvis ?>-3" title="3 étoiles"><i class="fa fa-star"></i></label>
                                                                    <input type="radio" id="edit-star-<?= $idAvis ?>-2" name="note" value="2" <?= (int)$avis['note'] === 2 ? 'checked' : '' ?>>
                                                                    <label for="edit-star-<?= $idAvis ?>-2" title="2 étoiles"><i class="fa fa-star"></i></label>
                                                                    <input type="radio" id="edit-star-<?= $idAvis ?>-1" name="note" value="1" <?= (int)$avis['note'] === 1 ? 'checked' : '' ?>>
                                                                    <label for="edit-star-<?= $idAvis ?>-1" title="1 étoile"><i class="fa fa-star"></i></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 text-md-end">
                                                                <button type="submit" class="btn btn-add-avis btn-sm">
                                                                    <i class="fa fa-floppy-disk me-1"></i>Enregistrer
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
