<?php
// config/database.php

define('DB_HOST', 'localhost');
define('DB_NAME', 'harfa_tunisie');
define('DB_USER', 'root');       // ← Changer selon votre config
define('DB_PASS', '');           // ← Changer selon votre config
define('DB_CHARSET', 'utf8mb4');

function getDBConnection(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:2rem;background:#fee;border:1px solid #f00;border-radius:8px;max-width:600px;margin:2rem auto">
                    <h3>❌ Erreur de connexion à la base de données</h3>
                    <p>' . htmlspecialchars($e->getMessage()) . '</p>
                    <p><strong>Vérifiez</strong> vos paramètres dans <code>config/database.php</code></p>
                 </div>');
        }
    }

    return $pdo;
}
