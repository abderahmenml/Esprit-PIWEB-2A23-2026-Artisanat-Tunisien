/**
 * =========================================================================
 *  حرفة Tunisie — Validation JavaScript du Module Investissement
 * =========================================================================
 * Fournit une validation en temps réel des formulaires d'enchère.
 * Feedback immédiat sur :
 * - Montant (numérique, > 0, >= budget_min, > enchère actuelle)
 * - Message (longueur minimum 20 caractères)
 * 
 * Utilisation : Inclure dans les vues avec <script src="/public/js/validation.js"></script>
 */

class EnchereValidator {
    /**
     * Constructor - Initialise le validateur
     * @param {number} budgetMin - Budget minimum du projet
     * @param {number} highestBid - Meilleure enchère actuelle
     */
    constructor(budgetMin = 0, highestBid = 0) {
        this.budgetMin = parseFloat(budgetMin);
        this.highestBid = parseFloat(highestBid);
        this.minimumThreshold = Math.max(this.budgetMin, this.highestBid);

        // Initialiser les références DOM
        this.initializeDOMReferences();
        this.setupEventListeners();
    }

    /**
     * initializeDOMReferences - Crée les références aux éléments du formulaire
     * @private
     */
    initializeDOMReferences() {
        // Montant de l'enchère
        this.montantInput = document.getElementById('montant');
        this.montantError = document.getElementById('montant-err');
        this.montantSuccess = document.getElementById('montant-ok');

        // Message de motivation
        this.messageTextarea = document.getElementById('message');
        this.messageError = document.getElementById('msg-err');
        this.charCount = document.getElementById('char-now');

        // Bouton de soumission
        this.submitButton = document.getElementById('btnSubmit');

        // Formulaire
        this.form = document.getElementById('frmEnchere');
    }

    /**
     * setupEventListeners - Attache les écouteurs d'événements
     * @private
     */
    setupEventListeners() {
        if (this.form) {
            this.form.addEventListener('submit', (e) => this.handleFormSubmit(e));
        }

        if (this.montantInput) {
            this.montantInput.addEventListener('input', () => this.validateMontant());
            this.montantInput.addEventListener('blur', () => this.validateMontant());
        }

        if (this.messageTextarea) {
            this.messageTextarea.addEventListener('input', () => this.validateMessage());
            this.messageTextarea.addEventListener('blur', () => this.validateMessage());
        }
    }

    /**
     * validateMontant - Valide le montant de l'enchère
     * 
     * Critères :
     * - Non vide
     * - Numérique
     * - > 0
     * - >= budget minimum
     * - > enchère précédente (si existe)
     * 
     * @returns {boolean} true si valide, false sinon
     */
    validateMontant() {
        if (!this.montantInput || !this.montantError || !this.montantSuccess) {
            return false;
        }

        const value = this.montantInput.value.trim();

        // Réinitialiser les messages
        this.montantError.style.display = 'none';
        this.montantSuccess.style.display = 'none';
        this.montantInput.classList.remove('is-valid', 'is-invalid');

        // Vérification 1 : Champ non vide
        if (value === '') {
            this.setMontantError('Le montant est obligatoire.');
            return false;
        }

        // Vérification 2 : Valeur numérique
        if (isNaN(value)) {
            this.setMontantError('Entrez un nombre valide.');
            return false;
        }

        const montantNum = parseFloat(value);

        // Vérification 3 : Montant > 0
        if (montantNum <= 0) {
            this.setMontantError('Le montant doit être supérieur à 0 TND.');
            return false;
        }

        // Vérification 4 : Montant >= budget minimum
        if (montantNum < this.budgetMin) {
            const budgetFormatted = this.formatCurrency(this.budgetMin);
            this.setMontantError(`Le montant minimum requis est ${budgetFormatted} TND.`);
            return false;
        }

        // Vérification 5 : Montant > enchère précédente
        if (this.highestBid > 0 && montantNum <= this.highestBid) {
            const bidFormatted = this.formatCurrency(this.highestBid);
            this.setMontantError(
                `Votre offre doit dépasser ${bidFormatted} TND ` +
                `(meilleure offre actuelle).`
            );
            return false;
        }

        // Succès - Montant valide
        this.montantInput.classList.add('is-valid');
        this.montantSuccess.style.display = 'block';
        this.updateSubmitButtonState();

        return true;
    }

    /**
     * validateMessage - Valide le message de motivation
     * 
     * Critères :
     * - Minimum 20 caractères
     * - Mise à jour du compteur de caractères
     * 
     * @returns {boolean} true si valide, false sinon
     */
    validateMessage() {
        if (!this.messageTextarea || !this.messageError || !this.charCount) {
            return false;
        }

        const text = this.messageTextarea.value.trim();
        const length = text.length;

        // Mise à jour du compteur
        this.charCount.textContent = length;

        // Réinitialiser les classes
        this.messageTextarea.classList.remove('is-valid', 'is-invalid');
        this.messageError.style.display = 'none';

        // Vérification : Minimum 20 caractères
        if (length < 20) {
            this.messageTextarea.classList.add('is-invalid');
            this.messageError.textContent =
                `Trop court : ${length}/20 caractères minimum.`;
            this.messageError.style.display = 'block';
            this.charCount.parentElement.style.color = '#dc3545';
            this.updateSubmitButtonState();
            return false;
        }

        // Succès - Message valide
        this.messageTextarea.classList.add('is-valid');
        this.charCount.parentElement.style.color = '#28a745';
        this.updateSubmitButtonState();

        return true;
    }

    /**
     * handleFormSubmit - Gestionnaire de soumission du formulaire
     * Valide les deux champs avant de soumettre
     * 
     * @param {Event} event L'événement submit
     */
    handleFormSubmit(event) {
        const isMontantValid = this.validateMontant();
        const isMessageValid = this.validateMessage();

        if (!isMontantValid || !isMessageValid) {
            event.preventDefault();

            // Scroll vers le premier champ invalide
            const invalidField = this.form.querySelector('.is-invalid');
            if (invalidField) {
                invalidField.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });
                invalidField.focus();
            }
        }
    }

    /**
     * updateSubmitButtonState - Désactive/Active le bouton submit
     * selon la validité du formulaire
     * @private
     */
    updateSubmitButtonState() {
        if (!this.submitButton) return;

        const isMontantValid = this.montantInput?.classList.contains('is-valid') || false;
        const isMessageValid = this.messageTextarea?.classList.contains('is-valid') || false;

        this.submitButton.disabled = !(isMontantValid && isMessageValid);
    }

    /**
     * setMontantError - Affiche un message d'erreur pour le montant
     * @private
     * @param {string} message Message d'erreur
     */
    setMontantError(message) {
        if (this.montantInput) {
            this.montantInput.classList.add('is-invalid');
        }
        if (this.montantError) {
            this.montantError.textContent = `⚠️ ${message}`;
            this.montantError.style.display = 'block';
        }
        this.updateSubmitButtonState();
    }

    /**
     * formatCurrency - Formate un nombre en devise française
     * @private
     * @param {number} value Valeur à formater
     * @returns {string} Valeur formatée (ex: "1 000" au lieu de "1000")
     */
    formatCurrency(value) {
        return value.toLocaleString('fr-FR');
    }

    /**
     * getFormData - Récupère les données du formulaire validées
     * @returns {Object} Objet contenant {montant, message}
     */
    getFormData() {
        return {
            montant: this.montantInput ? parseFloat(this.montantInput.value) : 0,
            message: this.messageTextarea ? this.messageTextarea.value.trim() : ''
        };
    }

    /**
     * reset - Réinitialise le formulaire et la validation
     */
    reset() {
        if (this.form) {
            this.form.reset();
        }
        this.montantInput?.classList.remove('is-valid', 'is-invalid');
        this.messageTextarea?.classList.remove('is-valid', 'is-invalid');
        if (this.montantError) this.montantError.style.display = 'none';
        if (this.messageError) this.messageError.style.display = 'none';
        if (this.montantSuccess) this.montantSuccess.style.display = 'none';
        if (this.charCount) this.charCount.textContent = '0';
        this.updateSubmitButtonState();
    }
}

/**
 * Initialisation automatique au chargement du DOM
 * Crée une instance du validateur si les éléments requis existent
 */
document.addEventListener('DOMContentLoaded', function() {
    // Récupère les valeurs depuis les attributs data du formulaire
    const form = document.getElementById('frmEnchere');

    if (form) {
        const budgetMin = parseFloat(form.dataset.budgetMin || 0);
        const highestBid = parseFloat(form.dataset.highestBid || 0);

        // Création de l'instance du validateur
        window.enchereValidator = new EnchereValidator(budgetMin, highestBid);

        console.log('✓ Validateur d\'enchère initialisé');
    }

    // Masquer les alertes flash après 8 secondes
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.classList.remove('show');
            alert.style.display = 'none';
        }, 8000);
    });
});
